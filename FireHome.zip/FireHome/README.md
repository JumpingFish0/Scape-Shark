# Fire Home

Launcher para Fire TV Stick no estilo do dashboard do Xbox. Ao focar um app, ele aparece grande no fundo.

- Tile grande **Canais** (TV ao vivo) que abre a lista M3U8, organizada por categoria
- Linha de **streamings** (Netflix, Prime Video, HBO Max, Disney+, Globoplay, YouTube...). Instalados abrem direto, os que faltam levam para a loja da Fire TV
- **Todos os apps**, **Loja de apps**, **Continuar assistindo**, **Favoritos** e **Configuracoes**
- Player HLS em tela cheia com troca de canal pelo controle e fallback automatico entre fontes
- O launcher inteiro se escala para qualquer resolucao (720p, 1080p, 4K) mantendo a mesma proporcao

## Compilar

1. Instale o Android Studio (versao recente) e abra a pasta `FireHome`.
2. Aguarde o Gradle sincronizar (precisa de internet na primeira vez).
3. Menu **Build > Select Build Variant** e escolha **release** (bem mais fluido que debug no Fire Stick).
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK fica em `app/build/outputs/apk/release/app-release.apk`.

## Instalar no Fire TV Stick

1. No Fire Stick: **Configuracoes > Meu Fire TV > Opcoes do desenvolvedor** e ligue **Depuracao ADB** e **Apps de fontes desconhecidas**.
   (Se nao aparecer "Opcoes do desenvolvedor": **Sobre** e aperte OK 7 vezes sobre o nome do aparelho.)
2. Anote o IP em **Sobre > Rede**.
3. No computador:

```
adb connect IP_DO_FIRE_STICK:5555
adb install -r app-release.apk
```

O app aparece em **Seus apps e canais** como **Fire Home**.

## Usar como tela inicial

O Fire OS nao deixa trocar a tela inicial pelas configuracoes. Tem dois caminhos:

- **Simples:** abra o Fire Home pela lista de apps. Dentro dele o botao Home do controle volta para a tela principal do launcher.
- **Botao Home abrindo o Fire Home:** use um app que remapeia o botao Home (por exemplo o "Button Mapper") e aponte para o Fire Home. Nao e oficial e pode parar de funcionar com atualizacoes do Fire OS.

## Controles

| Tela | Botao | Acao |
|---|---|---|
| Home | Setas / OK | Navegar / abrir |
| Canais | OK | Assistir |
| Canais | Menu ou segurar OK | Favoritar |
| Player | Cima / Baixo | Trocar de canal |
| Player | Esquerda / Direita | Trocar a qualidade (fonte) |
| Player | OK | Mostrar ou esconder informacoes |
| Todos os apps | Menu ou segurar OK | Detalhes e desinstalar |
| Qualquer | Voltar | Voltar um nivel |

## Trocar a playlist de canais (sem recompilar)

Na tela inicial, abra o tile **Playlist**, digite ou cole o link da lista `.m3u` / `.m3u8` e escolha **Salvar e carregar**.

- Dica: o app **Fire TV** (da Amazon) no celular tem um teclado que digita direto no campo.
- Se nao digitar `http` ou `https`, o app usa `https`.
- Links do GitHub no formato `github.com/.../blob/...` sao convertidos para o link direto do arquivo.
- Uma lista que nao tenha canais validos e recusada e nao apaga a que ja funciona.
- **Restaurar padrao** volta para a lista original do launcher.
- Se a lista nao carregar, a tela de Canais mostra o botao **Trocar playlist**.

## Se um canal nao tocar

O player le streams HLS (`.m3u8`) e fluxos diretos (`.ts`, `.mp4`, links sem extensao), detectando o formato sozinho. Se um canal falhar, a tela mostra o motivo, por exemplo "Servidor respondeu HTTP 404" (link fora do ar) ou "Falha de conexao". Isso quase sempre indica que o endereco do canal na lista esta vencido ou fora do ar, e nao e algo que o app consiga corrigir.

## Personalizar

- **Lista de canais:** `app/src/main/java/com/firehome/tv/data/AppConfig.kt` (`PLAYLIST_URL`). A lista e baixada ao abrir, guardada no aparelho e atualizada a cada 6 horas (`CACHE_TTL_HOURS`).
- **Conteudo adulto:** `HIDE_ADULT = true` esconde essas categorias da lista.
- **Streamings na tela inicial:** `data/StreamingCatalog.kt`. Para incluir outro, adicione uma linha com o nome do pacote (`adb shell pm list packages` mostra os pacotes instalados).
- **Cores e proporcoes:** `ui/Theme.kt` e `ui/HomeScreen.kt`.
