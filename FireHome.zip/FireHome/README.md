# Fire Home

Launcher para Fire TV Stick no estilo do painel do Xbox: o item em foco aparece grande no fundo.

- **Canais**: TV ao vivo dentro do próprio launcher (lista por categoria, player, guia Agora/A seguir e troca de servidor). Os canais vêm da API `api.reidoscanais.im`; precisa de internet. OK no canal escolhido abre em tela cheia.
- **Perfis**: até 6 perfis, cada um com seu papel de parede e seu "Continuar". Com mais de um perfil, o launcher pergunta quem está assistindo ao abrir. Segure OK ou aperte Menu num perfil para renomear ou excluir.
- **Continuar de onde parou**: faixa com os últimos apps e canais abertos no perfil.
- **Busca**: procura apps instalados e canais.
- **Clima**: previsão pelo Open-Meteo (sem chave). A cidade inicial vem do endereço de internet; dá para trocar na tela Clima.
- **Papel de parede**: 8 temas incluídos.
- **Streaming**: Netflix, Prime Video, HBO Max etc. Se não estiver instalado, OK abre a página na loja.
- **Atalhos**: Todos os apps, Loja de apps, Rede, Configurações.
- Em "Todos os apps": segure OK ou aperte Menu para ver detalhes/desinstalar.

## Como gerar o APK

Android Studio: abra a pasta e rode `assembleRelease`.
Pelo celular: envie o zip para o GitHub; o workflow gera o APK em Releases.

## Personalizar

- `data/ChannelsRepository.kt`: endereço da API de canais.
- `ui/WallpaperScreen.kt`: lista de temas.
- `data/StreamingCatalog.kt`: lista de serviços, pacotes e cores.
