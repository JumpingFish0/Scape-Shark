# Fire Home

Launcher para Fire TV Stick no estilo do painel do Xbox: o item em foco aparece grande no fundo.

- **Canais**: TV ao vivo dentro do próprio launcher (lista por categoria, player, guia Agora/A seguir e troca de servidor). Os canais vêm da API `api.reidoscanais.im`; precisa de internet. OK no canal escolhido abre em tela cheia.
- **Papel de parede**: 8 temas incluídos.
- **Streaming**: Netflix, Prime Video, HBO Max etc. Se não estiver instalado, OK abre a página na loja.
- **Atalhos**: Todos os apps, Loja de apps, Rede, Configurações.
- Em "Todos os apps": segure OK ou aperte Menu para ver detalhes/desinstalar.

## Como gerar o APK

Android Studio: abra a pasta e rode `assembleRelease`.
Pelo celular: envie o zip para o GitHub; o workflow gera o APK em Releases.

## Personalizar

- `data/ChannelsRepository.kt`: endereço da API de canais.
- `ui/WallpaperScreen.kt`: lista de temas.
- `data/StreamingCatalog.kt`: lista de serviços, pacotes e cores.
