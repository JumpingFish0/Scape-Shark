# FireHome com APK de Canais embutido

O APK `+Canais_MOD_v1.0.0_(TV)_androidtunado.com.apk` foi incluído em:

`app/src/main/assets/canais.apk`

## Como funciona

1. O usuário instala somente o APK do FireHome.
2. Na primeira seleção de **Canais**, o FireHome verifica se o app de Canais já está instalado.
3. Se não estiver, no Android 8 ou superior o FireHome abre a tela de autorização para instalar apps desconhecidos. Essa autorização é necessária por aplicativo e não pode ser concedida silenciosamente por um app comum.
4. Ao voltar das configurações com a autorização concedida, o FireHome extrai o APK interno e abre o instalador do Android/Fire OS.
5. O usuário confirma a instalação. Depois disso, selecionar **Canais** abre o app instalado.

## Limitações importantes

- O Android/Fire OS sempre exige confirmação do usuário para instalar um APK por esse método; não há instalação silenciosa em um Fire TV Stick comum sem privilégios de sistema/ADB.
- O app de Canais continua sendo um pacote separado no Android, embora o arquivo de instalação venha dentro do FireHome. Portanto, isto é um instalador agrupado, não uma incorporação do código do app de Canais no processo do FireHome.
- Se já houver uma versão instalada com assinatura diferente, o Android pode recusar a atualização. Nesse caso, será necessário remover a versão antiga antes de instalar a incluída; isso pode apagar os dados locais dela.
- O projeto usa o identificador de pacote que estava configurado no FireHome original: `com.empresa.potiguar.de.comunicacao`. Confirme que ele corresponde ao APK distribuído antes de publicar.

## Compilar

Abra a pasta `FireHome` no Android Studio, sincronize o Gradle e gere o APK em **Build > Build APK(s)**. A versão `release` do projeto está configurada para usar a chave debug local, adequada apenas para testes; para distribuição, configure uma chave de assinatura própria e mantenha-a em segurança.
