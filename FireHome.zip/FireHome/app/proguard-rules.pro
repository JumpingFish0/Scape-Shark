# Regras extras de R8 (normalmente nao e necessario nada alem do padrao).
