package com.firehome.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Papel de parede incluso no launcher: tudo desenhado em codigo, sem arquivos de imagem. */
data class Wallpaper(
    val name: String,
    val base: List<Color>,
    val glowA: Color,
    val glowB: Color,
)

val Wallpapers = listOf(
    Wallpaper("Meia-noite", listOf(Color(0xFF0B1020), Color(0xFF111B3A), Color(0xFF080B12)), Color(0xFF2F4BFF), Color(0xFF7B2FFF)),
    Wallpaper("Aurora", listOf(Color(0xFF06161C), Color(0xFF0B3B3A), Color(0xFF080B12)), Color(0xFF1DE9B6), Color(0xFF5E35B1)),
    Wallpaper("Pôr do sol", listOf(Color(0xFF1B0A1F), Color(0xFF5A1E3C), Color(0xFF0B0810)), Color(0xFFFF7043), Color(0xFFD81B60)),
    Wallpaper("Oceano", listOf(Color(0xFF03121F), Color(0xFF06355C), Color(0xFF040A12)), Color(0xFF29B6F6), Color(0xFF00897B)),
    Wallpaper("Floresta", listOf(Color(0xFF07140C), Color(0xFF123A1E), Color(0xFF050A07)), Color(0xFF66BB6A), Color(0xFFC0CA33)),
    Wallpaper("Neon", listOf(Color(0xFF10051F), Color(0xFF2A0B4D), Color(0xFF07030F)), Color(0xFFE040FB), Color(0xFF00E5FF)),
    Wallpaper("Vinho", listOf(Color(0xFF1A060B), Color(0xFF4A0F1F), Color(0xFF0A0306)), Color(0xFFE53935), Color(0xFFFF8A65)),
    Wallpaper("Grafite", listOf(Color(0xFF101114), Color(0xFF24272E), Color(0xFF08090B)), Color(0xFF90A4AE), Color(0xFF5C6BC0)),
)

fun wallpaperAt(index: Int): Wallpaper = Wallpapers[index.coerceIn(0, Wallpapers.lastIndex)]

fun Modifier.wallpaper(w: Wallpaper): Modifier = this.drawBehind {
    drawRect(
        Brush.linearGradient(w.base, start = Offset.Zero, end = Offset(size.width, size.height))
    )
    val a = Offset(size.width * 0.15f, size.height * 0.1f)
    val b = Offset(size.width * 0.9f, size.height * 0.95f)
    val r = size.maxDimension * 0.6f
    drawCircle(
        brush = Brush.radialGradient(listOf(w.glowA.copy(alpha = 0.40f), Color.Transparent), center = a, radius = r),
        radius = r,
        center = a,
    )
    drawCircle(
        brush = Brush.radialGradient(listOf(w.glowB.copy(alpha = 0.32f), Color.Transparent), center = b, radius = r),
        radius = r,
        center = b,
    )
}

@Composable
fun WallpaperScreen(selected: Int, onSelect: (Int) -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(60)
        runCatching { first.requestFocus() }
    }

    Box(Modifier.fillMaxSize().wallpaper(wallpaperAt(selected))) {
        Box(Modifier.fillMaxSize().background(Color(0x66000000)))
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 48.dp)
                .padding(top = 26.dp, bottom = 20.dp)
        ) {
            TopBar(title = "Papel de parede")
            Spacer(Modifier.height(6.dp))
            Text(
                "Escolha com o controle e aperte OK. O fundo muda na hora.",
                color = Palette.TextSecondary,
                fontSize = 12.sp,
            )
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(10.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                itemsIndexed(Wallpapers) { index, w ->
                    FocusTile(
                        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                        focusRequester = if (index == selected) first else if (selected !in Wallpapers.indices && index == 0) first else null,
                        shape = RoundedCornerShape(14.dp),
                        onClick = { onSelect(index) },
                    ) {
                        Box(Modifier.fillMaxSize().wallpaper(w))
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color(0xB0000000))
                            )
                        )
                        Text(
                            w.name,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
                        )
                        if (index == selected) {
                            Box(Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                                StatusChip("Em uso", Palette.Ok)
                            }
                        }
                    }
                }
            }
        }
    }
}
