package com.firehome.tv.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("firehome", Context.MODE_PRIVATE)

    fun favorites(): Set<String> = sp.getStringSet("favs", emptySet())?.toSet() ?: emptySet()

    fun saveFavorites(ids: Set<String>) {
        sp.edit().putStringSet("favs", ids).apply()
    }

    fun lastChannelId(): String? = sp.getString("last", null)

    fun setLastChannel(id: String) {
        sp.edit().putString("last", id).apply()
    }
}
