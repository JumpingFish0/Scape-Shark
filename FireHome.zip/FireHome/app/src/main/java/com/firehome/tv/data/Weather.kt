package com.firehome.tv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

data class Place(val name: String, val lat: Double, val lon: Double) {
    fun toJson(): String = JSONObject().put("name", name).put("lat", lat).put("lon", lon).toString()

    companion object {
        fun fromJson(s: String?): Place? = runCatching {
            val o = JSONObject(s ?: return null)
            Place(o.getString("name"), o.getDouble("lat"), o.getDouble("lon"))
        }.getOrNull()
    }
}

data class ForecastDay(val label: String, val min: Int, val max: Int, val code: Int)

data class Weather(
    val place: Place,
    val temp: Int,
    val feels: Int,
    val humidity: Int,
    val wind: Int,
    val code: Int,
    val days: List<ForecastDay>,
)

/** Clima pelo Open-Meteo (gratis, sem chave). A cidade inicial vem do endereco de internet (IP). */
object WeatherRepository {

    suspend fun locateByIp(): Result<Place> = withContext(Dispatchers.IO) {
        runCatching {
            val o = JSONObject(Http.get("https://ipwho.is/"))
            if (!o.optBoolean("success", true)) error("Localização indisponível")
            Place(o.optString("city").ifBlank { "Minha cidade" }, o.getDouble("latitude"), o.getDouble("longitude"))
        }
    }

    suspend fun search(query: String): Result<List<Place>> = withContext(Dispatchers.IO) {
        runCatching {
            val q = URLEncoder.encode(query.trim(), "UTF-8")
            val root = JSONObject(
                Http.get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=6&language=pt&format=json")
            )
            val arr = root.optJSONArray("results") ?: return@runCatching emptyList<Place>()
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val name = buildString {
                    append(o.optString("name"))
                    val admin = o.optString("admin1")
                    if (admin.isNotBlank()) append(", ").append(admin)
                    val country = o.optString("country_code")
                    if (country.isNotBlank()) append(" (").append(country).append(")")
                }
                Place(name, o.getDouble("latitude"), o.getDouble("longitude"))
            }
        }
    }

    suspend fun fetch(place: Place): Result<Weather> = withContext(Dispatchers.IO) {
        runCatching {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${place.lat}&longitude=${place.lon}" +
                "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5"
            val root = JSONObject(Http.get(url))
            val cur = root.getJSONObject("current")
            val daily = root.getJSONObject("daily")
            val times = daily.getJSONArray("time")
            val codes = daily.getJSONArray("weather_code")
            val maxs = daily.getJSONArray("temperature_2m_max")
            val mins = daily.getJSONArray("temperature_2m_min")
            val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val show = SimpleDateFormat("EEE", Locale.forLanguageTag("pt-BR"))
            val days = (0 until times.length()).map { i ->
                val label = if (i == 0) "Hoje" else {
                    val d = parse.parse(times.getString(i))
                    if (d != null) show.format(d).replaceFirstChar { it.uppercase() } else times.getString(i)
                }
                ForecastDay(label, Math.round(mins.getDouble(i)).toInt(), Math.round(maxs.getDouble(i)).toInt(), codes.getInt(i))
            }
            Weather(
                place = place,
                temp = Math.round(cur.getDouble("temperature_2m")).toInt(),
                feels = Math.round(cur.getDouble("apparent_temperature")).toInt(),
                humidity = cur.getInt("relative_humidity_2m"),
                wind = Math.round(cur.getDouble("wind_speed_10m")).toInt(),
                code = cur.getInt("weather_code"),
                days = days,
            )
        }
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Céu limpo"
        1 -> "Quase limpo"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Neblina"
        in 51..57 -> "Garoa"
        in 61..67 -> "Chuva"
        in 71..77 -> "Neve"
        in 80..82 -> "Pancadas de chuva"
        85, 86 -> "Neve forte"
        in 95..99 -> "Tempestade"
        else -> "Tempo variável"
    }
}
