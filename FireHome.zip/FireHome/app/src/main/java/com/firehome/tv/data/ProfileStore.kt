package com.firehome.tv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Profile(val id: Int, val name: String, val color: Int)

/** Item de "Continuar de onde parou": um app ou um canal. */
data class Recent(
    val kind: String, // "app" ou "channel"
    val key: String, // pacote do app ou id do canal
    val label: String,
    val extra: String?, // logo do canal
    val ts: Long,
)

/** Guarda perfis e, para cada perfil, o papel de parede e os itens recentes. */
class ProfileStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("firehome", Context.MODE_PRIVATE)

    fun profiles(): List<Profile> {
        val raw = prefs.getString("profiles", null)
        val list = runCatching {
            val arr = JSONArray(raw ?: return@runCatching emptyList<Profile>())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Profile(o.getInt("id"), o.getString("name"), o.optInt("color", 0))
            }
        }.getOrDefault(emptyList())
        return list.ifEmpty { listOf(Profile(1, "Perfil 1", 0)) }
    }

    fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("color", it.color)) }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    fun currentId(profiles: List<Profile>): Int {
        val id = prefs.getInt("current_profile", profiles.first().id)
        return if (profiles.any { it.id == id }) id else profiles.first().id
    }

    fun setCurrent(id: Int) = prefs.edit().putInt("current_profile", id).apply()

    fun wallpaper(id: Int): Int = prefs.getInt("p${id}_wallpaper", if (id == 1) prefs.getInt("wallpaper", 0) else 0)

    fun setWallpaper(id: Int, index: Int) = prefs.edit().putInt("p${id}_wallpaper", index).apply()

    fun recents(id: Int): List<Recent> = runCatching {
        val arr = JSONArray(prefs.getString("p${id}_recents", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Recent(
                kind = o.getString("kind"),
                key = o.getString("key"),
                label = o.getString("label"),
                extra = o.optString("extra").ifBlank { null },
                ts = o.optLong("ts"),
            )
        }
    }.getOrDefault(emptyList())

    /** Coloca o item no topo da lista do perfil (sem repetir) e mantem os 12 mais recentes. */
    fun addRecent(id: Int, item: Recent): List<Recent> {
        val list = (listOf(item) + recents(id).filterNot { it.kind == item.kind && it.key == item.key }).take(12)
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("kind", it.kind).put("key", it.key).put("label", it.label)
                    .put("extra", it.extra ?: "").put("ts", it.ts)
            )
        }
        prefs.edit().putString("p${id}_recents", arr.toString()).apply()
        return list
    }

    fun deleteProfileData(id: Int) {
        prefs.edit().remove("p${id}_wallpaper").remove("p${id}_recents").apply()
    }

    fun place(): Place? = Place.fromJson(prefs.getString("weather_place", null))

    fun setPlace(p: Place) = prefs.edit().putString("weather_place", p.toJson()).apply()
}
