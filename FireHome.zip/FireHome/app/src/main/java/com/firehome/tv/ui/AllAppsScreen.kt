package com.firehome.tv.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.firehome.tv.data.AppEntry
import kotlinx.coroutines.delay

@Composable
fun AllAppsScreen(
    apps: List<AppEntry>,
    onOpen: (AppEntry) -> Unit,
    onDetails: (AppEntry) -> Unit,
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(apps.isNotEmpty()) {
        if (apps.isNotEmpty()) {
            delay(60)
            runCatching { first.requestFocus() }
        }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF131A2B), Palette.Bg))
        )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 48.dp)
                .padding(top = 26.dp, bottom = 20.dp)
        ) {
            TopBar(title = "Todos os apps")
            Spacer(Modifier.height(6.dp))
            Text(
                "OK abre o app  ·  segure OK ou use Menu para ver detalhes e desinstalar",
                color = Palette.TextSecondary,
                fontSize = 12.sp,
            )
            Spacer(Modifier.height(10.dp))

            if (apps.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhum app encontrado", color = Palette.TextSecondary, fontSize = 16.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    itemsIndexed(apps, key = { _, app -> app.packageName }) { index, app ->
                        AppTile(
                            app = app,
                            focusRequester = if (index == 0) first else null,
                            onClick = { onOpen(app) },
                            onLongClick = { onDetails(app) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppTile(
    app: AppEntry,
    focusRequester: FocusRequester?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val banner = app.banner
    val icon = app.icon

    FocusTile(
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
        focusRequester = focusRequester,
        onClick = onClick,
        onLongClick = onLongClick,
    ) {
        Box(Modifier.fillMaxSize().background(Palette.PanelHi))
        if (banner != null) {
            Image(
                bitmap = banner,
                contentDescription = app.label,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = app.label,
                    modifier = Modifier.align(Alignment.Center).padding(bottom = 14.dp).size(48.dp),
                )
            }
            Text(
                app.label,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
            )
        }
    }
}
