package com.firehome.tv.data

import androidx.compose.ui.graphics.Color

/**
 * Servicos de streaming que aparecem na tela inicial.
 *
 * Para adicionar outro: inclua uma linha com o nome do pacote do app.
 * Para descobrir o pacote, no PC: adb shell pm list packages | findstr nome
 * A ordem aqui e a ordem na tela (os instalados vem primeiro).
 */
object StreamingCatalog {
    val services: List<StreamingService> = listOf(
        StreamingService("netflix", "Netflix", listOf("com.netflix.ninja"), Color(0xFFE50914)),
        StreamingService(
            "prime", "Prime Video",
            listOf("com.amazon.amazonvideo.livingroom", "com.amazon.avod"),
            Color(0xFF00A8E1),
        ),
        StreamingService(
            "hbomax", "HBO Max",
            listOf("com.wbd.stream", "com.hbo.hbonow", "com.hbo.max"),
            Color(0xFF5822B4),
        ),
        StreamingService("disney", "Disney+", listOf("com.disney.disneyplus"), Color(0xFF113CCF)),
        StreamingService("globoplay", "Globoplay", listOf("com.globo.globotv"), Color(0xFFE6204A)),
        StreamingService(
            "youtube", "YouTube",
            listOf("com.amazon.firetv.youtube", "com.google.android.youtube.tv"),
            Color(0xFFD50000),
        ),
        StreamingService(
            "appletv", "Apple TV",
            listOf("com.apple.atve.amazon.appletv"),
            Color(0xFF2B2B30),
        ),
        StreamingService(
            "paramount", "Paramount+",
            listOf("com.cbs.ott", "com.cbs.app", "com.cbs.ca"),
            Color(0xFF0064FF),
        ),
        StreamingService(
            "crunchyroll", "Crunchyroll",
            listOf("com.crunchyroll.crunchyroid"),
            Color(0xFFF47521),
        ),
        StreamingService("pluto", "Pluto TV", listOf("tv.pluto.android"), Color(0xFF3B3B98)),
        StreamingService("tubi", "Tubi", listOf("com.tubitv"), Color(0xFFFA382F)),
        StreamingService(
            "spotify", "Spotify",
            listOf("com.spotify.tv.android"),
            Color(0xFF1DB954),
        ),
        StreamingService(
            "twitch", "Twitch",
            listOf("tv.twitch.android.viewer"),
            Color(0xFF9146FF),
        ),
        StreamingService("plex", "Plex", listOf("com.plexapp.android"), Color(0xFFE5A00D)),
        StreamingService("kodi", "Kodi", listOf("org.xbmc.kodi"), Color(0xFF17B2E7)),
    )
}
