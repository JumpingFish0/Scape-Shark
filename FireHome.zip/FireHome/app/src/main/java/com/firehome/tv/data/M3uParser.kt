package com.firehome.tv.data

import java.io.BufferedReader
import java.text.Normalizer

/**
 * Le uma lista M3U e devolve os canais organizados por categoria.
 *
 * - Emojis e prefixos como "Canais" sao removidos dos nomes das categorias.
 * - Versoes FHD / HD / SD / 4K do mesmo canal viram um unico canal com varias fontes.
 * - Conteudo adulto e ocultado quando [AppConfig.HIDE_ADULT] estiver ligado.
 */
object M3uParser {

    private val attrRegex = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")
    private val qualityRegex = Regex("\\s+(FHD|UHD|4K|HD|SD)$", RegexOption.IGNORE_CASE)
    private val noiseSuffix = Regex("[\\s*²¹³]+$")
    private val canaisPrefix = Regex("^canais\\s+", RegexOption.IGNORE_CASE)
    private val spaces = Regex("\\s+")
    private val accents = Regex("\\p{M}+")

    // "adult tv" / "adult iptv" / "live adult" em vez de "adult" solto, para nao esconder o canal Adult Swim.
    private val adultWords = listOf(
        "xxx", "adultos", "adult tv", "adult iptv", "live adult", "onlyfans",
        "hardcore", "porn", "erotic", "playboy", "18+", "+18",
    )

    private val prettyGroups = mapOf(
        "documentarios" to "Documentários",
        "noticias" to "Notícias",
        "filmes e series" to "Filmes e Séries",
        "area do cliente" to "Área do cliente",
        "sbt" to "SBT",
        "hbo" to "HBO",
        "nba ppv" to "NBA PPV",
        "record tv" to "Record TV",
        "ufc" to "UFC",
        "cine sky" to "Cine SKY",
    )

    private val groupOrder = listOf(
        "abertos", "noticias", "esporte", "filmes", "variedades", "infantis",
        "documentarios", "hbo", "telecine", "disney", "discovery", "4k",
    )

    private class Builder(val id: String, val name: String, val group: String) {
        var logo: String? = null
        val sources = LinkedHashMap<String, Source>()
    }

    fun parse(reader: BufferedReader, hideAdult: Boolean = AppConfig.HIDE_ADULT): List<ChannelGroup> {
        val groups = LinkedHashMap<String, LinkedHashMap<String, Builder>>()

        var title = ""
        var logo: String? = null
        var rawGroup = ""
        var pending = false

        while (true) {
            val raw = reader.readLine() ?: break
            val line = raw.replace("﻿", "").trim()
            if (line.isEmpty()) continue

            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val attrs = attrRegex.findAll(line).associate {
                    it.groupValues[1].lowercase() to it.groupValues[2]
                }
                title = line.substringAfterLast(',', "").trim()
                    .ifEmpty { attrs["tvg-name"].orEmpty() }
                    .replace("﻿", "")
                    .trim()
                logo = attrs["tvg-logo"]?.trim()?.takeIf { it.startsWith("http", ignoreCase = true) }
                rawGroup = attrs["group-title"].orEmpty()
                pending = title.isNotEmpty()
            } else if (!line.startsWith("#")) {
                if (pending && line.startsWith("http", ignoreCase = true)) {
                    add(groups, title, logo, rawGroup, line, hideAdult)
                }
                pending = false
            }
        }

        return groups.entries
            .map { (groupName, channels) ->
                ChannelGroup(
                    name = groupName,
                    channels = channels.values.map { b ->
                        Channel(
                            id = b.id,
                            name = b.name,
                            logo = b.logo,
                            group = b.group,
                            sources = b.sources.values.sortedBy { qualityRank(it.quality) },
                        )
                    },
                )
            }
            .filter { it.channels.isNotEmpty() }
            .sortedBy { groupRank(it.name) }
    }

    private fun add(
        groups: LinkedHashMap<String, LinkedHashMap<String, Builder>>,
        title: String,
        logo: String?,
        rawGroup: String,
        url: String,
        hideAdult: Boolean,
    ) {
        val group = cleanGroup(rawGroup)
        if (hideAdult && isAdult(rawGroup, title, logo)) return

        val noPrefix = title.removePrefix("BR:").trim()
        var base = noPrefix.replace(noiseSuffix, "")
        var quality = ""
        qualityRegex.find(base)?.let { m ->
            quality = m.groupValues[1].uppercase()
            base = base.removeRange(m.range).trim()
        }
        if (quality == "UHD") quality = "4K"
        if (base.isEmpty()) base = noPrefix

        val id = "$group|${base.lowercase()}"
        val builder = groups.getOrPut(group) { LinkedHashMap() }
            .getOrPut(id) { Builder(id, base, group) }
        if (builder.logo == null) builder.logo = logo
        builder.sources.putIfAbsent(url, Source(quality, url))
    }

    private fun isAdult(rawGroup: String, title: String, logo: String?): Boolean {
        val hay = "$rawGroup $title".lowercase()
        if (adultWords.any { hay.contains(it) }) return true
        return logo?.contains("xvbroker", ignoreCase = true) == true
    }

    private fun cleanGroup(raw: String): String {
        val filtered = raw.filter { it.isLetterOrDigit() || it == ' ' || it in "&+-/" }
        var name = filtered.replace(spaces, " ").trim().replace(canaisPrefix, "").trim()
        if (name.isEmpty()) name = "Outros"
        return prettyGroups[normalize(name)] ?: name
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase()

    private fun groupRank(name: String): Int {
        val n = normalize(name)
        val idx = groupOrder.indexOfFirst { n.contains(it) }
        return if (idx >= 0) idx else 100
    }

    private fun qualityRank(q: String): Int = when (q) {
        "HD" -> 0
        "FHD" -> 1
        "" -> 2
        "SD" -> 3
        else -> 4
    }
}
