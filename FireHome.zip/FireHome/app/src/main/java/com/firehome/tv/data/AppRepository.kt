package com.firehome.tv.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Descobre os apps instalados e separa os servicos de streaming conhecidos. */
class AppRepository(context: Context) {
    private val ctx = context.applicationContext

    suspend fun load(): AppsState = withContext(Dispatchers.Default) {
        val pm = ctx.packageManager
        val seen = LinkedHashMap<String, AppEntry>()

        // Apps de TV primeiro, depois os demais apps com icone de lancamento.
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            val results = runCatching { pm.queryIntentActivities(query, 0) }.getOrDefault(emptyList())
            for (ri in results) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || seen.containsKey(pkg)) continue

                val label = runCatching { ri.loadLabel(pm).toString() }.getOrDefault(pkg)
                val banner: Drawable? = runCatching {
                    ri.activityInfo.loadBanner(pm) ?: ri.activityInfo.applicationInfo.loadBanner(pm)
                }.getOrNull()
                val icon: Drawable? = runCatching { ri.loadIcon(pm) }.getOrNull()

                seen[pkg] = AppEntry(
                    label = label,
                    packageName = pkg,
                    icon = icon?.toImage(160, 160),
                    banner = banner?.toImage(256, 144),
                )
            }
        }

        val streaming = StreamingCatalog.services.map { service ->
            val installed = service.packages.firstNotNullOfOrNull { seen[it] }
            StreamingItem(service, installed)
        }
        // Instalados primeiro, mantendo a ordem do catalogo dentro de cada grupo.
        val ordered = streaming.filter { it.app != null } + streaming.filter { it.app == null }

        AppsState(
            streaming = ordered,
            all = seen.values.sortedBy { it.label.lowercase() },
        )
    }

    private fun Drawable.toImage(width: Int, height: Int): ImageBitmap? =
        runCatching { toBitmap(width, height, Bitmap.Config.ARGB_8888).asImageBitmap() }.getOrNull()
}
