package com.firehome.tv.data

import java.net.URI

/** Limpeza e validacao do endereco da playlist digitado pelo usuario. */
object PlaylistUrl {
    private val githubBlob =
        Regex("^https?://github\\.com/([^/]+)/([^/]+)/blob/(.+)$", RegexOption.IGNORE_CASE)
    private val whitespace = Regex("\\s+")

    /**
     * Devolve o endereco pronto para uso ou null se for invalido.
     * - remove espacos (links colados em varias linhas)
     * - acrescenta https:// quando o usuario nao digitou o protocolo
     * - converte links "github.com/.../blob/..." para o link direto (raw) do arquivo
     */
    fun normalize(raw: String): String? {
        var s = raw.replace(whitespace, "")
        if (s.isEmpty()) return null
        if (!s.startsWith("http://", ignoreCase = true) && !s.startsWith("https://", ignoreCase = true)) {
            s = "https://$s"
        }
        githubBlob.find(s)?.let {
            s = "https://raw.githubusercontent.com/${it.groupValues[1]}/${it.groupValues[2]}/${it.groupValues[3]}"
        }
        val host = runCatching { URI(s).host }.getOrNull()
        return if (host.isNullOrBlank() || !host.contains('.')) null else s
    }

    fun host(url: String): String = runCatching { URI(url).host }.getOrNull()?.takeIf { it.isNotBlank() } ?: url
}
