package com.firehome.tv.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.firehome.tv.R
import com.firehome.tv.data.AppsState
import com.firehome.tv.data.Channel
import com.firehome.tv.data.StreamingItem
import kotlinx.coroutines.delay

/**
 * Tela inicial no estilo do dashboard do Xbox:
 * tile grande de Canais a esquerda, linha de streamings e linha de atalhos.
 * O item com foco aparece em tamanho grande no fundo.
 */
@Composable
fun HomeScreen(
    apps: AppsState,
    channelCount: Int,
    lastChannel: Channel?,
    favoriteCount: Int,
    playlistHost: String,
    initialFocusKey: String,
    onFocusKey: (String) -> Unit,
    onOpenChannels: () -> Unit,
    onOpenFavorites: () -> Unit,
    onOpenPlaylist: () -> Unit,
    onContinue: () -> Unit,
    onOpenAllApps: () -> Unit,
    onOpenStreaming: (StreamingItem) -> Unit,
    onOpenStore: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val requesters = remember { mutableMapOf<String, FocusRequester>() }
    fun req(key: String): FocusRequester = requesters.getOrPut(key) { FocusRequester() }

    var focusKey by remember { mutableStateOf(initialFocusKey) }
    fun focusTo(key: String) {
        focusKey = key
        onFocusKey(key)
    }

    val canais = FocusInfo(
        key = "canais",
        title = "Canais",
        subtitle = if (channelCount > 0) "TV ao vivo  ·  $channelCount canais" else "TV ao vivo",
        color = Color(0xFF3949AB),
        live = true,
    )
    val focus: FocusInfo = when {
        focusKey == "apps" -> FocusInfo(
            "apps", "Todos os apps", "Tudo o que está instalado neste aparelho",
            Color(0xFF37474F), iconRes = R.drawable.ic_apps,
        )

        focusKey == "store" -> FocusInfo(
            "store", "Loja de apps", "Baixe novos aplicativos e streamings",
            Color(0xFFE68A00), iconRes = R.drawable.ic_store,
        )

        focusKey == "favs" -> FocusInfo(
            "favs", "Favoritos", "$favoriteCount canais favoritos",
            Color(0xFFB8860B), iconRes = R.drawable.ic_star,
        )

        focusKey == "playlist" -> FocusInfo(
            "playlist", "Playlist de canais", "Lista atual: $playlistHost  ·  OK para trocar",
            Color(0xFF00695C), iconRes = R.drawable.ic_link,
        )

        focusKey == "settings" -> FocusInfo(
            "settings", "Configurações", "Rede, imagem, som e mais",
            Color(0xFF455A64), iconRes = R.drawable.ic_settings,
        )

        focusKey == "continue" && lastChannel != null -> FocusInfo(
            "continue", lastChannel.name, "Continuar assistindo",
            Color(0xFF00695C), iconRes = R.drawable.ic_play,
        )

        focusKey.startsWith("svc:") -> apps.streaming
            .firstOrNull { "svc:${it.service.id}" == focusKey }
            ?.let { item ->
                FocusInfo(
                    key = focusKey,
                    title = item.service.name,
                    subtitle = if (item.app != null) {
                        "Pressione OK para abrir"
                    } else {
                        "Não instalado  ·  OK para baixar na loja"
                    },
                    color = item.service.color,
                    image = item.app?.banner,
                    icon = item.app?.icon,
                )
            } ?: canais

        else -> canais
    }

    LaunchedEffect(Unit) {
        delay(80)
        val ok = runCatching { req(initialFocusKey).requestFocus() }.isSuccess
        if (!ok) runCatching { req("canais").requestFocus() }
    }

    Box(Modifier.fillMaxSize()) {
        Backdrop(focus)

        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 48.dp)
                .padding(top = 26.dp, bottom = 34.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            TopBar()

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // Coluna da esquerda: Canais (destaque) + Todos os apps
                Column(Modifier.width(232.dp)) {
                    FocusTile(
                        modifier = Modifier.fillMaxWidth().height(240.dp),
                        focusRequester = req("canais"),
                        onFocus = { focusTo("canais") },
                        onClick = onOpenChannels,
                    ) {
                        Box(Modifier.fillMaxSize().liveArt(0.5f, 0.38f, 0.52f))
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color(0xCC000000))
                            )
                        )
                        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                            Text("Canais", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("TV ao vivo", color = Palette.TextSecondary, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    FocusTile(
                        modifier = Modifier.fillMaxWidth().height(100.dp),
                        focusRequester = req("apps"),
                        onFocus = { focusTo("apps") },
                        onClick = onOpenAllApps,
                    ) { focused ->
                        PanelContent(R.drawable.ic_apps, "Todos os apps", null, focused)
                    }
                }

                // Coluna da direita: titulo, streamings e atalhos
                Column(Modifier.weight(1f)) {
                    Column(
                        Modifier.fillMaxWidth().height(120.dp).padding(start = 6.dp),
                        verticalArrangement = Arrangement.Bottom,
                    ) {
                        Text(
                            focus.title,
                            color = Color.White,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            focus.subtitle,
                            color = Palette.TextSecondary,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(12.dp))
                    }

                    LazyRow(
                        modifier = Modifier.fillMaxWidth().height(128.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        items(apps.streaming, key = { it.service.id }) { item ->
                            val key = "svc:${item.service.id}"
                            StreamingTile(
                                item = item,
                                focusRequester = req(key),
                                onFocus = { focusTo(key) },
                                onClick = { onOpenStreaming(item) },
                            )
                        }
                    }

                    LazyRow(
                        modifier = Modifier.fillMaxWidth().height(116.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        item(key = "store") {
                            FocusTile(
                                modifier = Modifier.width(190.dp).height(100.dp),
                                focusRequester = req("store"),
                                onFocus = { focusTo("store") },
                                onClick = onOpenStore,
                            ) { focused ->
                                PanelContent(R.drawable.ic_store, "Loja de apps", "Baixar apps", focused)
                            }
                        }
                        if (lastChannel != null) {
                            item(key = "continue") {
                                FocusTile(
                                    modifier = Modifier.width(190.dp).height(100.dp),
                                    focusRequester = req("continue"),
                                    onFocus = { focusTo("continue") },
                                    onClick = onContinue,
                                ) { focused ->
                                    PanelContent(
                                        R.drawable.ic_history,
                                        lastChannel.name,
                                        "Continuar assistindo",
                                        focused,
                                    )
                                    if (lastChannel.logo != null) {
                                        AsyncImage(
                                            model = lastChannel.logo,
                                            contentDescription = null,
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(10.dp)
                                                .size(34.dp),
                                        )
                                    }
                                }
                            }
                        }
                        item(key = "favs") {
                            FocusTile(
                                modifier = Modifier.width(190.dp).height(100.dp),
                                focusRequester = req("favs"),
                                onFocus = { focusTo("favs") },
                                onClick = onOpenFavorites,
                            ) { focused ->
                                PanelContent(R.drawable.ic_star, "Favoritos", "$favoriteCount canais", focused)
                            }
                        }
                        item(key = "playlist") {
                            FocusTile(
                                modifier = Modifier.width(190.dp).height(100.dp),
                                focusRequester = req("playlist"),
                                onFocus = { focusTo("playlist") },
                                onClick = onOpenPlaylist,
                            ) { focused ->
                                PanelContent(R.drawable.ic_link, "Playlist", playlistHost, focused)
                            }
                        }
                        item(key = "settings") {
                            FocusTile(
                                modifier = Modifier.width(190.dp).height(100.dp),
                                focusRequester = req("settings"),
                                onFocus = { focusTo("settings") },
                                onClick = onOpenSettings,
                            ) { focused ->
                                PanelContent(R.drawable.ic_settings, "Configurações", null, focused)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamingTile(
    item: StreamingItem,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    val service = item.service
    val banner = item.app?.banner
    val icon = item.app?.icon

    FocusTile(
        modifier = Modifier.width(176.dp).height(112.dp),
        focusRequester = focusRequester,
        onFocus = onFocus,
        onClick = onClick,
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.linearGradient(
                    listOf(
                        service.color,
                        service.color.copy(alpha = 0.55f).compositeOver(Color.Black),
                    )
                )
            )
        )
        when {
            banner != null -> Image(
                bitmap = banner,
                contentDescription = service.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )

            icon != null -> {
                Image(
                    bitmap = icon,
                    contentDescription = service.name,
                    modifier = Modifier.align(Alignment.Center).size(56.dp),
                )
                Text(
                    item.app?.label ?: service.name,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp, start = 8.dp, end = 8.dp),
                )
            }

            else -> {
                Text(
                    service.name,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    modifier = Modifier.align(Alignment.Center).padding(horizontal = 10.dp),
                )
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_download),
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(14.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("Instalar", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun BoxScope.PanelContent(iconRes: Int, title: String, subtitle: String?, focused: Boolean) {
    Box(Modifier.matchParentSize().background(if (focused) Palette.PanelHi else Palette.Panel))
    Icon(
        painter = painterResource(iconRes),
        contentDescription = null,
        tint = Color.White,
        modifier = Modifier.align(Alignment.TopStart).padding(14.dp).size(28.dp),
    )
    Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
        Text(
            title,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (subtitle != null) {
            Text(
                subtitle,
                color = Palette.TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
