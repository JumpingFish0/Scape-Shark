package com.firehome.tv.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.firehome.tv.R
import com.firehome.tv.data.AppsState
import com.firehome.tv.data.Profile
import com.firehome.tv.data.Recent
import com.firehome.tv.data.StreamingItem
import com.firehome.tv.data.Weather
import com.firehome.tv.data.WeatherRepository
import kotlinx.coroutines.delay

private const val KEY_CHANNELS = "canais"
private const val KEY_APPS = "apps"
private const val KEY_STORE = "store"
private const val KEY_WIFI = "wifi"
private const val KEY_SETTINGS = "settings"
private const val KEY_WALLPAPER = "wallpaper"
private const val KEY_SEARCH = "search"
private const val KEY_WEATHER = "weather"
private const val KEY_PROFILES = "profiles"
private fun svcKey(id: String) = "svc:$id"
private fun recKey(r: Recent) = "rec:${r.kind}:${r.key}"

@Composable
fun HomeScreen(
    apps: AppsState,
    initialFocusKey: String,
    onFocusKey: (String) -> Unit,
    profile: Profile?,
    weather: Weather?,
    recents: List<Recent>,
    wallpaper: Int,
    onOpenChannels: () -> Unit,
    onOpenAllApps: () -> Unit,
    onOpenStreaming: (StreamingItem) -> Unit,
    onOpenRecent: (Recent) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenProfiles: () -> Unit,
    onOpenStore: () -> Unit,
    onOpenWifi: () -> Unit,
    onOpenWallpapers: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    // Itens de "Continuar": apps so entram se ainda estiverem instalados.
    val visibleRecents = remember(apps, recents) {
        recents.filter { r -> r.kind == "channel" || apps.all.any { it.packageName == r.key } }.take(8)
    }

    val infos = HashMap<String, FocusInfo>()
    infos[KEY_CHANNELS] = FocusInfo(
        key = KEY_CHANNELS, title = "Canais", subtitle = "TV ao vivo direto no launcher",
        color = Color(0xFF3A1C71), live = true,
    )
    infos[KEY_APPS] = FocusInfo(
        key = KEY_APPS, title = "Todos os apps", subtitle = "${apps.all.size} apps instalados neste aparelho",
        color = Color(0xFF1F3A5F), iconRes = R.drawable.ic_apps,
    )
    infos[KEY_SEARCH] = FocusInfo(
        key = KEY_SEARCH, title = "Busca", subtitle = "Procure apps e canais",
        color = Color(0xFF0D47A1), iconRes = R.drawable.ic_search,
    )
    infos[KEY_WEATHER] = FocusInfo(
        key = KEY_WEATHER, title = "Clima",
        subtitle = if (weather != null) {
            "${weather.place.name.substringBefore(",")}: ${weather.temp}°C, ${WeatherRepository.describe(weather.code)}"
        } else "Previsão do tempo",
        color = Color(0xFF0277BD), iconRes = R.drawable.ic_cloud,
    )
    infos[KEY_PROFILES] = FocusInfo(
        key = KEY_PROFILES, title = "Perfis", subtitle = "Perfil atual: ${profile?.name ?: "-"}",
        color = Color(0xFF4527A0), iconRes = R.drawable.ic_person,
    )
    infos[KEY_STORE] = FocusInfo(
        key = KEY_STORE, title = "Loja de apps", subtitle = "Baixe novos apps na Appstore da Fire TV",
        color = Color(0xFFB45F06), iconRes = R.drawable.ic_store,
    )
    infos[KEY_WIFI] = FocusInfo(
        key = KEY_WIFI, title = "Rede", subtitle = "Conectar ao Wi-Fi",
        color = Color(0xFF00695C), iconRes = R.drawable.ic_wifi,
    )
    infos[KEY_WALLPAPER] = FocusInfo(
        key = KEY_WALLPAPER, title = "Papel de parede", subtitle = "Escolha o fundo do launcher",
        color = Color(0xFF6A1B9A), iconRes = R.drawable.ic_wallpaper,
    )
    infos[KEY_SETTINGS] = FocusInfo(
        key = KEY_SETTINGS, title = "Configurações", subtitle = "Ajustes do aparelho",
        color = Color(0xFF37474F), iconRes = R.drawable.ic_settings,
    )
    apps.streaming.forEach { item ->
        val app = item.app
        infos[svcKey(item.service.id)] = FocusInfo(
            key = svcKey(item.service.id),
            title = item.service.name,
            subtitle = if (app != null) "Pressione OK para abrir" else "Pressione OK para instalar na loja",
            color = item.service.color,
            image = app?.banner,
            icon = if (app?.banner == null) app?.icon else null,
            chip = if (app != null) "Instalado" else "Não instalado",
            chipColor = if (app != null) Palette.Ok else Palette.Warn,
        )
    }
    visibleRecents.forEach { r ->
        if (r.kind == "app") {
            val app = apps.all.firstOrNull { it.packageName == r.key }
            infos[recKey(r)] = FocusInfo(
                key = recKey(r), title = r.label, subtitle = "Continuar de onde parou",
                color = Color(0xFF263859), image = app?.banner,
                icon = if (app?.banner == null) app?.icon else null,
            )
        } else {
            infos[recKey(r)] = FocusInfo(
                key = recKey(r), title = r.label, subtitle = "Último canal assistido",
                color = Color(0xFF3A1C71), live = true,
            )
        }
    }

    var focusKey by remember { mutableStateOf(initialFocusKey) }
    val current = infos[focusKey] ?: infos.getValue(KEY_CHANNELS)

    val requesters = remember { HashMap<String, FocusRequester>() }
    fun req(key: String) = requesters.getOrPut(key) { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(80)
        val target = if (infos.containsKey(initialFocusKey)) initialFocusKey else KEY_CHANNELS
        val ok = runCatching { req(target).requestFocus() }.getOrDefault(false)
        if (!ok) runCatching { req(KEY_CHANNELS).requestFocus() }
    }

    fun focused(key: String) {
        focusKey = key
        onFocusKey(key)
    }

    Box(Modifier.fillMaxSize()) {
        Backdrop(current, wallpaperAt(wallpaper), Modifier.fillMaxSize())

        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 40.dp)
                .padding(top = 22.dp, bottom = 18.dp)
        ) {
            TopBar(weather = weather, profile = profile)
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxSize()) {
                // Esquerda: Canais em destaque + todos os apps.
                Column(Modifier.width(244.dp)) {
                    ChannelsTile(
                        modifier = Modifier.fillMaxWidth().height(256.dp),
                        focusRequester = req(KEY_CHANNELS),
                        onFocus = { focused(KEY_CHANNELS) },
                        onClick = onOpenChannels,
                    )
                    Spacer(Modifier.height(30.dp))
                    GlassTile(
                        title = "Todos os apps",
                        subtitle = "${apps.all.size} instalados",
                        iconRes = R.drawable.ic_apps,
                        modifier = Modifier.fillMaxWidth().height(88.dp),
                        focusRequester = req(KEY_APPS),
                        onFocus = { focused(KEY_APPS) },
                        onClick = onOpenAllApps,
                    )
                }

                Spacer(Modifier.width(36.dp))

                // Direita: titulo do item em foco + faixas (rolam na vertical).
                Column(Modifier.fillMaxSize()) {
                    TitleBlock(current, Modifier.height(96.dp))
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 24.dp),
                    ) {
                        if (visibleRecents.isNotEmpty()) {
                            item(key = "row-recents") {
                                Section("CONTINUAR") {
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                                    ) {
                                        items(visibleRecents, key = { recKey(it) }) { r ->
                                            RecentTile(
                                                recent = r,
                                                appIcon = apps.all.firstOrNull { it.packageName == r.key }?.icon,
                                                focusRequester = req(recKey(r)),
                                                onFocus = { focused(recKey(r)) },
                                                onClick = { onOpenRecent(r) },
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        item(key = "row-streaming") {
                            Section("STREAMING") {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                                ) {
                                    items(apps.streaming, key = { it.service.id }) { item ->
                                        val k = svcKey(item.service.id)
                                        StreamingTile(
                                            item = item,
                                            focusRequester = req(k),
                                            onFocus = { focused(k) },
                                            onClick = { onOpenStreaming(item) },
                                        )
                                    }
                                }
                            }
                        }
                        item(key = "row-shortcuts") {
                            Section("ATALHOS") {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                                ) {
                                    item {
                                        Shortcut("Busca", "Apps e canais", R.drawable.ic_search, req(KEY_SEARCH), { focused(KEY_SEARCH) }, onOpenSearch)
                                    }
                                    item {
                                        Shortcut(
                                            "Clima",
                                            if (weather != null) "${weather.temp}°C agora" else "Previsão",
                                            R.drawable.ic_cloud, req(KEY_WEATHER), { focused(KEY_WEATHER) }, onOpenWeather,
                                        )
                                    }
                                    item {
                                        Shortcut("Perfis", profile?.name ?: "Trocar", R.drawable.ic_person, req(KEY_PROFILES), { focused(KEY_PROFILES) }, onOpenProfiles)
                                    }
                                    item {
                                        Shortcut("Loja de apps", "Appstore", R.drawable.ic_store, req(KEY_STORE), { focused(KEY_STORE) }, onOpenStore)
                                    }
                                    item {
                                        Shortcut("Rede", "Wi-Fi", R.drawable.ic_wifi, req(KEY_WIFI), { focused(KEY_WIFI) }, onOpenWifi)
                                    }
                                    item {
                                        Shortcut("Papel de parede", "Temas", R.drawable.ic_wallpaper, req(KEY_WALLPAPER), { focused(KEY_WALLPAPER) }, onOpenWallpapers)
                                    }
                                    item {
                                        Shortcut("Configurações", "Ajustes", R.drawable.ic_settings, req(KEY_SETTINGS), { focused(KEY_SETTINGS) }, onOpenSettings)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Shortcut(
    title: String,
    subtitle: String,
    iconRes: Int,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    GlassTile(
        title = title,
        subtitle = subtitle,
        iconRes = iconRes,
        modifier = Modifier.width(190.dp).height(88.dp),
        focusRequester = focusRequester,
        onFocus = onFocus,
        onClick = onClick,
    )
}

@Composable
private fun Section(label: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            label,
            color = Palette.TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.6.sp,
            modifier = Modifier.padding(start = 8.dp, top = 6.dp),
        )
        content()
    }
}

@Composable
private fun TitleBlock(info: FocusInfo, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(start = 8.dp), verticalArrangement = Arrangement.Bottom) {
        if (info.chip != null) {
            StatusChip(info.chip, info.chipColor)
            Spacer(Modifier.height(6.dp))
        }
        Text(
            info.title,
            color = Color.White,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            info.subtitle,
            color = Palette.TextSecondary,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ChannelsTile(
    modifier: Modifier,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    FocusTile(
        modifier = modifier,
        focusRequester = focusRequester,
        shape = RoundedCornerShape(18.dp),
        onFocus = onFocus,
        onClick = onClick,
    ) {
        Box(Modifier.fillMaxSize().liveArt(0.5f, 0.38f, 0.5f, tv = true))
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color(0xCC000000))
            )
        )
        Row(
            Modifier.align(Alignment.TopStart).padding(12.dp)
                .background(Color(0xFFE53935), RoundedCornerShape(50))
                .padding(horizontal = 9.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(6.dp).background(Color.White, CircleShape))
            Spacer(Modifier.width(5.dp))
            Text("AO VIVO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text("Canais", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Assistir agora", color = Color(0xFFE0E4EC), fontSize = 12.sp)
        }
    }
}

@Composable
private fun StreamingTile(
    item: StreamingItem,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    val app = item.app
    val banner = app?.banner
    val icon = app?.icon

    FocusTile(
        modifier = Modifier.width(176.dp).height(112.dp),
        focusRequester = focusRequester,
        shape = RoundedCornerShape(14.dp),
        onFocus = onFocus,
        onClick = onClick,
    ) {
        if (banner != null) {
            Box(Modifier.fillMaxSize().background(Palette.PanelHi))
            Image(
                bitmap = banner,
                contentDescription = item.service.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(listOf(item.service.color, Color(0xFF0E121C)))
                )
            )
            if (app != null && icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = item.service.name,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(bottom = 18.dp)
                        .size(46.dp)
                        .clip(RoundedCornerShape(10.dp)),
                )
            } else if (app == null) {
                Icon(
                    painter = painterResource(R.drawable.ic_download),
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.align(Alignment.Center).padding(bottom = 18.dp).size(34.dp),
                )
            }
            Column(
                Modifier.align(Alignment.BottomCenter).padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    item.service.name,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (app == null) {
                    Text("Instalar", color = Color(0xFFE0E4EC), fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun RecentTile(
    recent: Recent,
    appIcon: ImageBitmap?,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    val logo = if (recent.kind == "channel") rememberRemoteImage(recent.extra) else appIcon
    GlassTile(
        title = recent.label,
        subtitle = if (recent.kind == "channel") "Canal" else "App",
        iconRes = if (recent.kind == "channel") R.drawable.ic_live_tv else null,
        iconBitmap = logo,
        modifier = Modifier.width(210.dp).height(72.dp),
        focusRequester = focusRequester,
        onFocus = onFocus,
        onClick = onClick,
    )
}

@Composable
internal fun GlassTile(
    title: String,
    subtitle: String,
    modifier: Modifier,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    iconRes: Int? = null,
    iconBitmap: ImageBitmap? = null,
) {
    FocusTile(
        modifier = modifier,
        focusRequester = focusRequester,
        shape = RoundedCornerShape(14.dp),
        onFocus = onFocus,
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    if (focused) listOf(Color(0xF03A4A72), Color(0xF01E2740))
                    else listOf(Color(0xCC1E2536), Color(0xCC121724))
                )
            )
        )
        Row(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .background(if (focused) Color(0x33FFFFFF) else Color(0x1FFFFFFF), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (iconBitmap != null) {
                    Image(
                        bitmap = iconBitmap,
                        contentDescription = null,
                        modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Fit,
                    )
                } else if (iconRes != null) {
                    Icon(
                        painter = painterResource(iconRes),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    subtitle,
                    color = Palette.TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
