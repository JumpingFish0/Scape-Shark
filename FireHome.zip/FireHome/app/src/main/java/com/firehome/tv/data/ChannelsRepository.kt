package com.firehome.tv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Embed(val provider: String, val quality: String, val url: String)

data class EpgItem(val title: String, val time: String)

data class Channel(
    val id: String,
    val name: String,
    val category: String,
    val logoUrl: String?,
    val embeds: List<Embed>,
    val now: EpgItem?,
    val next: EpgItem?,
)

sealed interface ChannelsState {
    data object Loading : ChannelsState
    data class Error(val message: String) : ChannelsState
    data class Ready(val channels: List<Channel>) : ChannelsState
}

/** Le a lista de canais da API (https://api.reidoscanais.im/channels). */
object ChannelsRepository {
    private const val URL_CHANNELS = "https://api.reidoscanais.im/channels"

    suspend fun load(): Result<List<Channel>> = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(URL_CHANNELS).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                setRequestProperty("Accept", "application/json")
            }
            try {
                if (conn.responseCode !in 200..299) error("A API respondeu HTTP ${conn.responseCode}")
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                parse(body)
            } finally {
                conn.disconnect()
            }
        }
    }

    private fun parse(body: String): List<Channel> {
        val trimmed = body.trim()
        val array: JSONArray = if (trimmed.startsWith("[")) {
            JSONArray(trimmed)
        } else {
            val root = JSONObject(trimmed)
            if (root.has("success") && !root.optBoolean("success", true)) {
                error(root.optString("message", "A API informou uma falha."))
            }
            root.optJSONArray("data") ?: root.optJSONArray("channels") ?: JSONArray()
        }
        val out = ArrayList<Channel>(array.length())
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val embeds = ArrayList<Embed>()
            o.optJSONArray("embeds")?.let { arr ->
                for (j in 0 until arr.length()) {
                    val e = arr.optJSONObject(j) ?: continue
                    val url = e.optString("embed_url")
                    if (url.startsWith("https://", ignoreCase = true)) {
                        embeds += Embed(
                            provider = e.optString("provider").ifBlank { "Servidor ${j + 1}" },
                            quality = e.optString("quality"),
                            url = url,
                        )
                    }
                }
            }
            val epg = o.optJSONObject("epg")
            val logo = o.optString("logo_url").takeIf { it.startsWith("https://", ignoreCase = true) }
            out += Channel(
                id = o.opt("id")?.toString() ?: i.toString(),
                name = o.optString("name").ifBlank { "Canal" },
                category = o.optString("category").ifBlank { "Sem categoria" },
                logoUrl = logo,
                embeds = embeds,
                now = epg?.optJSONObject("current")?.let(::epgItem),
                next = epg?.optJSONObject("next")?.let(::epgItem),
            )
        }
        if (out.isEmpty()) error("A API respondeu, mas não retornou canais.")
        return out
    }

    private fun epgItem(o: JSONObject): EpgItem? {
        val title = o.optString("title")
        if (title.isBlank()) return null
        return EpgItem(title, o.optString("formatted_time"))
    }
}
