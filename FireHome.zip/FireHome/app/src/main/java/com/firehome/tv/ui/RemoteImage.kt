package com.firehome.tv.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val cache = LruCache<String, ImageBitmap>(120)

private fun download(url: String): ImageBitmap? {
    val conn = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 8_000
        readTimeout = 8_000
    }
    return try {
        val bytes = conn.inputStream.use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 160 && bounds.outHeight / (sample * 2) >= 160) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.asImageBitmap()
    } finally {
        conn.disconnect()
    }
}

/** Baixa e guarda em cache uma imagem pequena (logo de canal). Devolve null enquanto carrega ou se falhar. */
@Composable
fun rememberRemoteImage(url: String?): ImageBitmap? {
    val state = produceState<ImageBitmap?>(initialValue = url?.let { cache.get(it) }, url) {
        if (url == null || value != null) return@produceState
        val img = withContext(Dispatchers.IO) { runCatching { download(url) }.getOrNull() }
        if (img != null) {
            cache.put(url, img)
            value = img
        }
    }
    return state.value
}
