package com.firehome.tv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

object Palette {
    val Bg = Color(0xFF0A0D14)
    val Panel = Color(0xD91A1F2B)
    val PanelHi = Color(0xF0293149)
    val Focus = Color(0xFF8AD4FF)
    val TextSecondary = Color(0xFFB4BDCB)
}

/**
 * Todas as medidas em dp foram pensadas para uma tela de 960 dp de largura.
 * Aqui a densidade e ajustada para que isso valha em qualquer TV (720p, 1080p, 4K),
 * entao o layout fica sempre com a mesma proporcao.
 */
@Composable
fun FireHomeTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val widthPx = context.resources.displayMetrics.widthPixels.coerceAtLeast(1)
    val density = remember(widthPx) { Density(density = widthPx / 960f, fontScale = 1f) }

    CompositionLocalProvider(LocalDensity provides density) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Palette.Bg,
                surface = Palette.Bg,
                primary = Palette.Focus,
                onBackground = Color.White,
                onSurface = Color.White,
            ),
            content = content,
        )
    }
}
