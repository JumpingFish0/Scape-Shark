package com.firehome.tv.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.firehome.tv.data.AppEntry
import kotlinx.coroutines.delay
import java.text.Normalizer

private fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().trim()

@Composable
fun SearchScreen(
    apps: List<AppEntry>,
    wallpaper: Int,
    onOpenApp: (AppEntry) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val field = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { field.requestFocus() }
    }

    val q = norm(query)
    val appHits = remember(q, apps) {
        if (q.isEmpty()) emptyList() else apps.filter { norm(it.label).contains(q) }.take(30)
    }
    Box(Modifier.fillMaxSize().wallpaper(wallpaperAt(wallpaper))) {
        Box(Modifier.fillMaxSize().background(Color(0x88000000)))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 48.dp).padding(top = 26.dp, bottom = 20.dp)
        ) {
            TopBar(title = "Busca")
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                modifier = Modifier.width(460.dp).focusRequester(field),
                textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                placeholder = { Text("Digite o nome de um app", color = Palette.TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Palette.Focus,
                    unfocusedBorderColor = Palette.Hairline,
                    cursorColor = Palette.Focus,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Aperte OK no campo para abrir o teclado. Desça para escolher um resultado.",
                color = Palette.TextSecondary,
                fontSize = 11.sp,
            )
            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                ResultColumn(
                    title = "APPS" + if (q.isNotEmpty()) " (${appHits.size})" else "",
                    modifier = Modifier.weight(1f),
                    empty = if (q.isEmpty()) "Os resultados aparecem aqui" else "Nenhum app encontrado",
                    isEmpty = appHits.isEmpty(),
                ) {
                    items(appHits, key = { it.packageName }) { app ->
                        ResultRow(app.label, "App", app.icon, app.label.take(1), { onOpenApp(app) })
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultColumn(
    title: String,
    modifier: Modifier,
    empty: String,
    isEmpty: Boolean,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    Column(modifier) {
        Text(
            title,
            color = Palette.TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.6.sp,
            modifier = Modifier.padding(start = 6.dp, bottom = 6.dp),
        )
        if (isEmpty) {
            Text(empty, color = Palette.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp))
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                content = content,
            )
        }
    }
}

@Composable
private fun ResultRow(title: String, subtitle: String, image: ImageBitmap?, letter: String, onClick: () -> Unit) {
    FocusTile(
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(12.dp),
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.fillMaxSize().background(if (focused) Color(0xF03A4A72) else Color(0xCC1A2030))
        )
        Row(
            Modifier.fillMaxSize().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x22FFFFFF)),
                contentAlignment = Alignment.Center,
            ) {
                if (image != null) {
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize().padding(3.dp),
                        contentScale = ContentScale.Fit,
                    )
                } else {
                    Text(letter.uppercase(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    subtitle, color = Palette.TextSecondary, fontSize = 11.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
