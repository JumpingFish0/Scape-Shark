package com.firehome.tv

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.firehome.tv.data.AppRepository
import com.firehome.tv.data.AppsState
import com.firehome.tv.data.Cats
import com.firehome.tv.data.Channel
import com.firehome.tv.data.ChannelGroup
import com.firehome.tv.data.ChannelRepository
import com.firehome.tv.data.Prefs
import com.firehome.tv.ui.LoadState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen { Home, Channels, AllApps, Player }

data class UiState(
    val screen: Screen = Screen.Home,
    val apps: AppsState = AppsState.Empty,
    val groups: List<ChannelGroup> = emptyList(),
    val loadState: LoadState = LoadState.Loading,
    val favorites: Set<String> = emptySet(),
    val homeFocus: String = "canais",
    val channelCategory: String = Cats.ALL,
    val playing: Channel? = null,
    val playlist: List<Channel> = emptyList(),
    val lastChannel: Channel? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val channelRepo = ChannelRepository(app)
    private val appRepo = AppRepository(app)
    private val prefs = Prefs(app)

    private val _state = MutableStateFlow(UiState(favorites = prefs.favorites()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var refreshJob: Job? = null

    init {
        reloadApps()
        loadChannels()
    }

    fun reloadApps() {
        viewModelScope.launch {
            val apps = appRepo.load()
            _state.update { it.copy(apps = apps) }
        }
    }

    /** Mostra a copia local na hora e atualiza pela internet em segundo plano quando precisar. */
    fun loadChannels(force: Boolean = false) {
        if (refreshJob?.isActive == true) return
        refreshJob = viewModelScope.launch {
            val cached = channelRepo.cached()
            if (cached != null) {
                _state.update {
                    it.copy(groups = cached, loadState = LoadState.Ready, lastChannel = findLast(cached))
                }
            } else {
                _state.update { it.copy(loadState = LoadState.Loading) }
            }

            if (force || cached == null || channelRepo.isStale()) {
                runCatching { channelRepo.refresh() }
                    .onSuccess { fresh ->
                        _state.update {
                            it.copy(groups = fresh, loadState = LoadState.Ready, lastChannel = findLast(fresh))
                        }
                    }
                    .onFailure {
                        if (cached == null) _state.update { s -> s.copy(loadState = LoadState.Error) }
                    }
            }
        }
    }

    private fun findLast(groups: List<ChannelGroup>): Channel? {
        val id = prefs.lastChannelId() ?: return null
        return groups.asSequence().flatMap { it.channels.asSequence() }.firstOrNull { it.id == id }
    }

    fun go(screen: Screen) = _state.update { it.copy(screen = screen) }

    fun setHomeFocus(key: String) = _state.update { it.copy(homeFocus = key) }

    fun setChannelCategory(key: String) = _state.update { it.copy(channelCategory = key) }

    fun openChannels(category: String = Cats.ALL) {
        _state.update { it.copy(screen = Screen.Channels, channelCategory = category) }
        if (_state.value.loadState != LoadState.Ready) loadChannels(force = true)
    }

    fun play(channel: Channel, list: List<Channel>) {
        _state.update { it.copy(screen = Screen.Player, playing = channel, playlist = list) }
    }

    /** Continua o ultimo canal assistido, usando a lista completa como fila. */
    fun continueLast() {
        val s = _state.value
        val last = s.lastChannel ?: return
        play(last, s.groups.flatMap { it.channels })
    }

    fun changeChannel(delta: Int) {
        val s = _state.value
        val list = s.playlist
        val current = s.playing ?: return
        if (list.isEmpty()) return
        val index = list.indexOfFirst { it.id == current.id }.takeIf { it >= 0 } ?: 0
        val next = list[(index + delta).mod(list.size)]
        _state.update { it.copy(playing = next) }
    }

    fun onWatched(channel: Channel) {
        prefs.setLastChannel(channel.id)
        _state.update { it.copy(lastChannel = channel) }
    }

    fun toggleFavorite(channel: Channel) {
        val updated = _state.value.favorites.toMutableSet().apply {
            if (!add(channel.id)) remove(channel.id)
        }
        prefs.saveFavorites(updated)
        _state.update { it.copy(favorites = updated) }
    }

    /** Trata o botao Voltar. Devolve false quando ja estiver na Home (nao ha para onde voltar). */
    fun back(): Boolean {
        val s = _state.value
        return when (s.screen) {
            Screen.Player -> { go(Screen.Channels); true }
            Screen.Channels, Screen.AllApps -> { go(Screen.Home); true }
            Screen.Home -> false
        }
    }
}
