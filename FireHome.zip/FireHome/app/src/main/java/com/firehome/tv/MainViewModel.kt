package com.firehome.tv

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.firehome.tv.data.AppRepository
import com.firehome.tv.data.AppsState
import com.firehome.tv.data.ChannelsRepository
import com.firehome.tv.data.ChannelsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen { Home, AllApps, Wallpapers, Channels }

data class UiState(
    val screen: Screen = Screen.Home,
    val apps: AppsState = AppsState.Empty,
    val homeFocus: String = "canais",
    val wallpaper: Int = 0,
    val channels: ChannelsState = ChannelsState.Loading,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val appRepo = AppRepository(app)
    private val prefs = app.getSharedPreferences("firehome", android.content.Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(UiState(wallpaper = prefs.getInt("wallpaper", 0)))
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        reloadApps()
    }

    fun reloadApps() {
        viewModelScope.launch {
            val apps = appRepo.load()
            _state.update { it.copy(apps = apps) }
        }
    }

    private var channelsJob: kotlinx.coroutines.Job? = null

    /** Carrega a lista de canais (uma vez; use force para tentar de novo). */
    fun loadChannels(force: Boolean = false) {
        val cur = _state.value.channels
        if (!force && cur is ChannelsState.Ready) return
        if (channelsJob?.isActive == true) return
        _state.update { it.copy(channels = ChannelsState.Loading) }
        channelsJob = viewModelScope.launch {
            val result = ChannelsRepository.load()
            _state.update {
                it.copy(
                    channels = result.fold(
                        onSuccess = { list -> ChannelsState.Ready(list) },
                        onFailure = { e -> ChannelsState.Error(e.message ?: "Falha de conexão") },
                    )
                )
            }
        }
    }

    fun setWallpaper(index: Int) {
        prefs.edit().putInt("wallpaper", index).apply()
        _state.update { it.copy(wallpaper = index) }
    }

    fun go(screen: Screen) = _state.update { it.copy(screen = screen) }

    fun setHomeFocus(key: String) = _state.update { it.copy(homeFocus = key) }

    /** Trata o botao Voltar. Devolve false quando ja estiver na Home (nao ha para onde voltar). */
    fun back(): Boolean = when (_state.value.screen) {
        Screen.AllApps, Screen.Wallpapers, Screen.Channels -> { go(Screen.Home); true }
        Screen.Home -> false
    }
}
