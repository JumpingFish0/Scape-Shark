package com.firehome.tv

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.firehome.tv.data.AppRepository
import com.firehome.tv.data.AppsState
import com.firehome.tv.data.Place
import com.firehome.tv.data.Profile
import com.firehome.tv.data.ProfileStore
import com.firehome.tv.data.Recent
import com.firehome.tv.data.Weather
import com.firehome.tv.data.WeatherRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen { Home, AllApps, Wallpapers, Profiles, Search, Weather }

data class UiState(
    val screen: Screen = Screen.Home,
    val apps: AppsState = AppsState.Empty,
    val homeFocus: String = "canais",
    val wallpaper: Int = 0,
    val profiles: List<Profile> = emptyList(),
    val profileId: Int = 1,
    val recents: List<Recent> = emptyList(),
    val weather: Weather? = null,
    val weatherFailed: Boolean = false,
    val placeResults: List<Place> = emptyList(),
    val placeSearching: Boolean = false,
    val placeSearchFailed: Boolean = false,
) {
    val profile: Profile? get() = profiles.firstOrNull { it.id == profileId }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val appRepo = AppRepository(app)
    private val store = ProfileStore(app)

    private val _state: MutableStateFlow<UiState>
    val state: StateFlow<UiState> get() = _state.asStateFlow()

    private var weatherJob: Job? = null
    private var weatherAt = 0L

    init {
        val profiles = store.profiles()
        val id = store.currentId(profiles)
        _state = MutableStateFlow(
            UiState(
                // Com mais de um perfil, o launcher abre perguntando quem vai assistir.
                screen = if (profiles.size > 1) Screen.Profiles else Screen.Home,
                profiles = profiles,
                profileId = id,
                wallpaper = store.wallpaper(id),
                recents = store.recents(id),
            )
        )
        reloadApps()
        loadWeather()
    }

    fun reloadApps() {
        viewModelScope.launch {
            val apps = appRepo.load()
            _state.update { it.copy(apps = apps) }
        }
    }

    fun go(screen: Screen) = _state.update { it.copy(screen = screen) }

    fun setHomeFocus(key: String) = _state.update { it.copy(homeFocus = key) }

    // ---- Papel de parede (por perfil) ----

    fun setWallpaper(index: Int) {
        store.setWallpaper(_state.value.profileId, index)
        _state.update { it.copy(wallpaper = index) }
    }

    // ---- Perfis ----

    fun selectProfile(id: Int) {
        store.setCurrent(id)
        _state.update {
            it.copy(
                profileId = id,
                wallpaper = store.wallpaper(id),
                recents = store.recents(id),
                homeFocus = "canais",
                screen = Screen.Home,
            )
        }
    }

    fun addProfile() {
        val list = _state.value.profiles
        if (list.size >= 6) return
        val id = (list.maxOfOrNull { it.id } ?: 0) + 1
        val profile = Profile(id, "Perfil ${list.size + 1}", list.size % 6)
        val updated = list + profile
        store.saveProfiles(updated)
        _state.update { it.copy(profiles = updated) }
    }

    fun renameProfile(id: Int, name: String) {
        val clean = name.trim().take(16).ifBlank { return }
        val updated = _state.value.profiles.map { if (it.id == id) it.copy(name = clean) else it }
        store.saveProfiles(updated)
        _state.update { it.copy(profiles = updated) }
    }

    fun deleteProfile(id: Int) {
        val list = _state.value.profiles
        if (list.size <= 1) return
        val updated = list.filterNot { it.id == id }
        store.saveProfiles(updated)
        store.deleteProfileData(id)
        val newCurrent = if (_state.value.profileId == id) updated.first().id else _state.value.profileId
        store.setCurrent(newCurrent)
        _state.update {
            it.copy(
                profiles = updated,
                profileId = newCurrent,
                wallpaper = store.wallpaper(newCurrent),
                recents = store.recents(newCurrent),
            )
        }
    }

    // ---- Continuar de onde parou ----

    fun recordApp(packageName: String, label: String) = record(Recent("app", packageName, label, null, System.currentTimeMillis()))

    private fun record(item: Recent) {
        val list = store.addRecent(_state.value.profileId, item)
        _state.update { it.copy(recents = list) }
    }

    // ---- Clima ----

    fun loadWeather(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && _state.value.weather != null && now - weatherAt < 30 * 60_000L) return
        if (weatherJob?.isActive == true) return
        weatherJob = viewModelScope.launch {
            val place = store.place() ?: WeatherRepository.locateByIp().getOrNull()?.also { store.setPlace(it) }
            if (place == null) {
                _state.update { it.copy(weatherFailed = true) }
                return@launch
            }
            WeatherRepository.fetch(place).fold(
                onSuccess = { w ->
                    weatherAt = System.currentTimeMillis()
                    _state.update { it.copy(weather = w, weatherFailed = false) }
                },
                onFailure = { _state.update { it.copy(weatherFailed = true) } },
            )
        }
    }

    fun searchPlaces(query: String) {
        if (query.isBlank()) return
        _state.update { it.copy(placeSearching = true, placeSearchFailed = false) }
        viewModelScope.launch {
            WeatherRepository.search(query).fold(
                onSuccess = { list -> _state.update { it.copy(placeResults = list, placeSearching = false) } },
                onFailure = { _state.update { it.copy(placeSearching = false, placeSearchFailed = true) } },
            )
        }
    }

    fun choosePlace(place: Place) {
        store.setPlace(place)
        _state.update { it.copy(placeResults = emptyList()) }
        loadWeather(force = true)
    }

    /** Trata o botao Voltar. Devolve false quando ja estiver na Home (nao ha para onde voltar). */
    fun back(): Boolean = when (_state.value.screen) {
        Screen.Home -> false
        else -> { go(Screen.Home); true }
    }
}
