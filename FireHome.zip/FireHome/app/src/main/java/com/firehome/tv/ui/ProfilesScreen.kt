package com.firehome.tv.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.firehome.tv.data.Profile
import kotlinx.coroutines.delay

@Composable
fun ProfilesScreen(
    profiles: List<Profile>,
    currentId: Int,
    wallpaper: Int,
    onSelect: (Int) -> Unit,
    onAdd: () -> Unit,
    onSave: (Int, String) -> Unit,
    onDelete: (Int) -> Unit,
) {
    var editing by remember { mutableStateOf<Profile?>(null) }
    var name by remember { mutableStateOf("") }
    val first = remember { FocusRequester() }
    val nameField = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(60)
        runCatching { first.requestFocus() }
    }
    LaunchedEffect(editing?.id) {
        if (editing != null) {
            delay(60)
            runCatching { nameField.requestFocus() }
        }
    }
    BackHandler(enabled = editing != null) { editing = null }

    Box(Modifier.fillMaxSize().wallpaper(wallpaperAt(wallpaper))) {
        Box(Modifier.fillMaxSize().background(Color(0x88000000)))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 48.dp).padding(top = 26.dp, bottom = 20.dp)
        ) {
            TopBar(title = "Perfis")
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Quem está assistindo?", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "OK entra no perfil  ·  segure OK ou aperte Menu para editar",
                    color = Palette.TextSecondary,
                    fontSize = 12.sp,
                )
                Spacer(Modifier.height(22.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(22.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                ) {
                    items(profiles, key = { it.id }) { p ->
                        ProfileCard(
                            label = p.name,
                            selected = p.id == currentId,
                            focusRequester = if (p.id == currentId) first else null,
                            avatar = { Avatar(p, 84.dp) },
                            onClick = { onSelect(p.id) },
                            onLongClick = {
                                editing = p
                                name = p.name
                            },
                        )
                    }
                    if (profiles.size < 6) {
                        item {
                            ProfileCard(
                                label = "Novo perfil",
                                selected = false,
                                focusRequester = null,
                                avatar = {
                                    Box(
                                        Modifier.size(84.dp).background(Color(0x33FFFFFF), CircleShape),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text("+", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Light)
                                    }
                                },
                                onClick = onAdd,
                                onLongClick = null,
                            )
                        }
                    }
                }

                val edit = editing
                if (edit != null) {
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it.take(16) },
                            singleLine = true,
                            modifier = Modifier.width(260.dp).focusRequester(nameField),
                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                            placeholder = { Text("Nome do perfil", color = Palette.TextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Palette.Focus,
                                unfocusedBorderColor = Palette.Hairline,
                                cursorColor = Palette.Focus,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                onSave(edit.id, name)
                                editing = null
                            }),
                        )
                        Spacer(Modifier.width(12.dp))
                        Pill("Salvar") {
                            onSave(edit.id, name)
                            editing = null
                        }
                        if (profiles.size > 1) {
                            Spacer(Modifier.width(10.dp))
                            Pill("Excluir") {
                                onDelete(edit.id)
                                editing = null
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Pill("Cancelar") { editing = null }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileCard(
    label: String,
    selected: Boolean,
    focusRequester: FocusRequester?,
    avatar: @Composable () -> Unit,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
) {
    FocusTile(
        modifier = Modifier.width(130.dp).height(150.dp),
        focusRequester = focusRequester,
        shape = RoundedCornerShape(18.dp),
        onLongClick = onLongClick,
        onClick = onClick,
    ) { focused ->
        Box(Modifier.fillMaxSize().background(if (focused) Color(0xF03A4A72) else Color(0xAA161B27)))
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            avatar()
            Spacer(Modifier.height(12.dp))
            Text(
                label,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
            )
            if (selected) {
                Spacer(Modifier.height(4.dp))
                StatusChip("Atual", Palette.Ok)
            }
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    FocusTile(
        modifier = Modifier.height(40.dp),
        shape = RoundedCornerShape(50),
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.background(if (focused) Color(0xF03A4A72) else Color(0xCC1E2536))
                .padding(horizontal = 18.dp).height(40.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
