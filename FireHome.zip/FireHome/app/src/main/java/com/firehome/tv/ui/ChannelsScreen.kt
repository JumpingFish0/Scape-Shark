package com.firehome.tv.ui

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.firehome.tv.data.Channel
import com.firehome.tv.data.ChannelsState
import kotlinx.coroutines.delay

@Composable
fun ChannelsScreen(state: ChannelsState, wallpaper: Int, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize().wallpaper(wallpaperAt(wallpaper))) {
        Box(Modifier.fillMaxSize().background(Color(0x77000000)))
        when (state) {
            ChannelsState.Loading -> Column(Modifier.fillMaxSize().padding(horizontal = 48.dp).padding(top = 26.dp)) {
                TopBar(title = "Canais")
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Carregando canais…", color = Palette.TextSecondary, fontSize = 16.sp)
                }
            }

            is ChannelsState.Error -> {
                val retry = remember { FocusRequester() }
                LaunchedEffect(Unit) {
                    delay(60)
                    runCatching { retry.requestFocus() }
                }
                Column(Modifier.fillMaxSize().padding(horizontal = 48.dp).padding(top = 26.dp)) {
                    TopBar(title = "Canais")
                    Column(
                        Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("Não foi possível carregar os canais", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text(state.message, color = Palette.TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(18.dp))
                        FocusTile(
                            modifier = Modifier.width(180.dp).height(44.dp),
                            focusRequester = retry,
                            shape = RoundedCornerShape(50),
                            onClick = onRetry,
                        ) { focused ->
                            Box(
                                Modifier.fillMaxSize().background(if (focused) Color(0xF03A4A72) else Color(0xCC1E2536)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("Tentar de novo", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            is ChannelsState.Ready -> ChannelsContent(state.channels)
        }
    }
}

@Composable
private fun ChannelsContent(all: List<Channel>) {
    var category by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Channel?>(null) }
    var serverIdx by remember { mutableIntStateOf(0) }
    var fullscreen by remember { mutableStateOf(false) }

    val categories = remember(all) { all.map { it.category }.distinct().sorted() }
    val shown = remember(all, category) { if (category == null) all else all.filter { it.category == category } }
    val first = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }

    val current = selected
    val embed = current?.embeds?.getOrNull(serverIdx)

    if (fullscreen && embed != null) {
        BackHandler(enabled = true) { fullscreen = false }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            WebPlayer(url = embed.url, interactive = true, modifier = Modifier.fillMaxSize())
        }
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp)
            .padding(top = 24.dp, bottom = 20.dp)
    ) {
        TopBar(title = "Canais")
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxSize()) {
            // Lista
            Column(Modifier.width(290.dp)) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                ) {
                    item { Chip("Todos", category == null) { category = null } }
                    items(categories, key = { it }) { c -> Chip(c, category == c) { category = c } }
                }
                Spacer(Modifier.height(6.dp))
                LazyColumn(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                ) {
                    items(shown, key = { it.id }) { ch ->
                        ChannelRow(
                            channel = ch,
                            active = selected?.id == ch.id,
                            focusRequester = if (ch === shown.first()) first else null,
                            onClick = {
                                if (selected?.id == ch.id && ch.embeds.isNotEmpty()) {
                                    fullscreen = true
                                } else {
                                    selected = ch
                                    serverIdx = 0
                                }
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.width(28.dp))

            // Player + informacoes
            Column(Modifier.fillMaxSize()) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF05070C))
                ) {
                    if (embed != null) {
                        WebPlayer(url = embed.url, interactive = false, modifier = Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize().liveArt(0.5f, 0.45f, 0.4f, tv = true))
                        Text(
                            if (current == null) "Escolha um canal e aperte OK" else "Este canal não tem servidor disponível",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp),
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (current != null) {
                    Text(
                        current.name,
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(current.category, color = Palette.TextSecondary, fontSize = 12.sp)
                    current.now?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Agora: ${it.title}" + if (it.time.isNotBlank()) "  ·  ${it.time}" else "",
                            color = Color.White,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    current.next?.let {
                        Text(
                            "A seguir: ${it.title}" + if (it.time.isNotBlank()) "  ·  ${it.time}" else "",
                            color = Palette.TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (current.embeds.size > 1) {
                        Spacer(Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                        ) {
                            items(current.embeds.size) { i ->
                                val e = current.embeds[i]
                                Chip(
                                    e.provider + if (e.quality.isNotBlank()) " · ${e.quality}" else "",
                                    i == serverIdx,
                                ) { serverIdx = i }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "OK no canal escolhido abre em tela cheia  ·  Voltar sai da tela cheia",
                        color = Palette.TextSecondary,
                        fontSize = 11.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    FocusTile(
        modifier = Modifier.height(30.dp),
        shape = RoundedCornerShape(50),
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.background(
                when {
                    focused -> Color(0xF03A4A72)
                    selected -> Color(0xCC2F4BFF)
                    else -> Color(0xCC1E2536)
                }
            ).padding(horizontal = 14.dp).height(30.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

@Composable
private fun ChannelRow(channel: Channel, active: Boolean, focusRequester: FocusRequester?, onClick: () -> Unit) {
    val logo = rememberRemoteImage(channel.logoUrl)
    FocusTile(
        modifier = Modifier.fillMaxWidth().height(56.dp),
        focusRequester = focusRequester,
        shape = RoundedCornerShape(12.dp),
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(
                    if (focused) listOf(Color(0xF03A4A72), Color(0xF01E2740))
                    else if (active) listOf(Color(0xCC2A2F7A), Color(0xCC161B2E))
                    else listOf(Color(0xCC1E2536), Color(0xCC121724))
                )
            )
        )
        Row(
            Modifier.fillMaxSize().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x22FFFFFF)),
                contentAlignment = Alignment.Center,
            ) {
                if (logo != null) {
                    Image(
                        bitmap = logo,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize().padding(3.dp),
                        contentScale = ContentScale.Fit,
                    )
                } else {
                    Text(
                        channel.name.take(1).uppercase(),
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    channel.name,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    channel.category,
                    color = Palette.TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

private const val SITE_ORIGIN = "https://api.reidoscanais.im/"

private fun playerHtml(url: String): String {
    val safe = url.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;")
    return "<!doctype html><html><head><meta charset=\"utf-8\">" +
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
        "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}" +
        "iframe{border:0;width:100%;height:100%}</style></head><body>" +
        "<iframe src=\"$safe\" allow=\"autoplay; encrypted-media; picture-in-picture; fullscreen\" " +
        "allowfullscreen referrerpolicy=\"strict-origin-when-cross-origin\"></iframe></body></html>"
}

/**
 * Mostra o player do provedor dentro de uma WebView. O embed e carregado em um iframe
 * (igual ao site de integracao), com o endereco do seu site como origem da pagina.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun WebPlayer(url: String, interactive: Boolean, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val root = FrameLayout(ctx).apply { setBackgroundColor(android.graphics.Color.BLACK) }
            val web = WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                )
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.javaScriptCanOpenWindowsAutomatically = false
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                // Player de navegador comum: tira a marca "wv" do identificador da WebView.
                settings.userAgentString = settings.userAgentString.replace("; wv", "")
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webViewClient = WebViewClient()
                isFocusable = interactive
                isFocusableInTouchMode = interactive
            }
            var custom: View? = null
            var customCb: WebChromeClient.CustomViewCallback? = null
            web.webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    custom?.let { root.removeView(it) }
                    custom = view
                    customCb = callback
                    web.visibility = View.GONE
                    root.addView(view, ViewGroup.LayoutParams(-1, -1))
                }

                override fun onHideCustomView() {
                    custom?.let { root.removeView(it) }
                    custom = null
                    customCb?.onCustomViewHidden()
                    customCb = null
                    web.visibility = View.VISIBLE
                }
            }
            root.addView(web)
            root.tag = web
            web.tag = url
            web.loadDataWithBaseURL(SITE_ORIGIN, playerHtml(url), "text/html", "utf-8", null)
            if (interactive) web.post { web.requestFocus() }
            root
        },
        update = { root ->
            val web = root.tag as WebView
            if (web.tag != url) {
                web.tag = url
                web.loadDataWithBaseURL(SITE_ORIGIN, playerHtml(url), "text/html", "utf-8", null)
            }
        },
        onRelease = { root ->
            (root.tag as? WebView)?.let {
                it.stopLoading()
                it.destroy()
            }
        },
    )
}
