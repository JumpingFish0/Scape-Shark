package com.firehome.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.firehome.tv.R
import com.firehome.tv.data.Cats
import com.firehome.tv.data.Channel
import com.firehome.tv.data.ChannelGroup
import com.firehome.tv.data.bestQuality
import kotlinx.coroutines.delay

enum class LoadState { Loading, Ready, Error }

private class Category(val key: String, val label: String, val count: Int)

/**
 * Area "Canais": categorias a esquerda, grade de canais a direita.
 * OK assiste, Menu ou segurar OK favorita.
 */
@Composable
fun ChannelsScreen(
    groups: List<ChannelGroup>,
    favorites: Set<String>,
    loadState: LoadState,
    startCategory: String,
    onCategory: (String) -> Unit,
    onPlay: (Channel, List<Channel>) -> Unit,
    onToggleFavorite: (Channel) -> Unit,
    onRetry: () -> Unit,
) {
    val allChannels = remember(groups) { groups.flatMap { it.channels } }
    val favChannels = remember(allChannels, favorites) { allChannels.filter { it.id in favorites } }

    val categories = remember(groups, favChannels, allChannels) {
        buildList {
            add(Category(Cats.FAV, "Favoritos", favChannels.size))
            add(Category(Cats.ALL, "Todos os canais", allChannels.size))
            groups.forEach { add(Category(it.name, it.name, it.channels.size)) }
        }
    }

    var selected by remember { mutableStateOf(startCategory) }
    if (categories.none { it.key == selected }) selected = Cats.ALL

    val channels = remember(selected, groups, allChannels, favChannels) {
        when (selected) {
            Cats.FAV -> favChannels
            Cats.ALL -> allChannels
            else -> groups.firstOrNull { it.name == selected }?.channels.orEmpty()
        }
    }

    val firstCategory = remember { FocusRequester() }
    LaunchedEffect(loadState == LoadState.Ready) {
        if (loadState == LoadState.Ready) {
            delay(60)
            runCatching { firstCategory.requestFocus() }
        }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF131A2B), Palette.Bg))
        )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 48.dp)
                .padding(top = 26.dp, bottom = 20.dp)
        ) {
            TopBar(title = "Canais")
            Spacer(Modifier.height(10.dp))

            when {
                loadState == LoadState.Loading && groups.isEmpty() -> CenterMessage("Carregando canais...", null, null)
                loadState == LoadState.Error && groups.isEmpty() ->
                    CenterMessage("Não foi possível carregar a lista de canais", "Tentar novamente", onRetry)

                else -> Row(Modifier.fillMaxSize()) {
                    LazyColumn(
                        modifier = Modifier.width(210.dp).fillMaxHeight(),
                        contentPadding = PaddingValues(vertical = 8.dp, horizontal = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        itemsIndexed(categories, key = { _, c -> c.key }) { index, cat ->
                            CategoryItem(
                                label = cat.label,
                                count = cat.count,
                                active = cat.key == selected,
                                focusRequester = if (cat.key == startCategory || (index == 1 && categories.none { it.key == startCategory })) firstCategory else null,
                                onFocus = {
                                    selected = cat.key
                                    onCategory(cat.key)
                                },
                            )
                        }
                    }

                    Spacer(Modifier.width(16.dp))

                    if (channels.isEmpty()) {
                        CenterMessage(
                            if (selected == Cats.FAV) {
                                "Nenhum favorito ainda. Segure OK ou aperte Menu em um canal para favoritar."
                            } else {
                                "Nenhum canal nesta categoria"
                            },
                            null,
                            null,
                        )
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            items(channels, key = { it.id }) { channel ->
                                ChannelTile(
                                    channel = channel,
                                    favorite = channel.id in favorites,
                                    onClick = { onPlay(channel, channels) },
                                    onLongClick = { onToggleFavorite(channel) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryItem(
    label: String,
    count: Int,
    active: Boolean,
    focusRequester: FocusRequester?,
    onFocus: () -> Unit,
) {
    FocusTile(
        modifier = Modifier.fillMaxWidth().height(44.dp),
        focusRequester = focusRequester,
        shape = RoundedCornerShape(8.dp),
        onFocus = onFocus,
        onClick = onFocus,
    ) { focused ->
        Box(
            Modifier.matchParentSize().background(
                when {
                    focused -> Palette.PanelHi
                    active -> Color(0x66293149)
                    else -> Color(0x33FFFFFF)
                }
            )
        )
        Row(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                label,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text("$count", color = Palette.TextSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ChannelTile(
    channel: Channel,
    favorite: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    FocusTile(
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 10f),
        shape = RoundedCornerShape(8.dp),
        onClick = onClick,
        onLongClick = onLongClick,
    ) { focused ->
        Box(Modifier.matchParentSize().background(if (focused) Palette.PanelHi else Palette.Panel))

        if (channel.logo != null) {
            AsyncImage(
                model = channel.logo,
                contentDescription = channel.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(bottom = 22.dp)
                    .fillMaxWidth(0.6f)
                    .fillMaxHeight(0.55f),
            )
        } else {
            Text(
                channel.name.take(3).uppercase(),
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Center).padding(bottom = 18.dp),
            )
        }

        Text(
            channel.name,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 8.dp, vertical = 8.dp),
        )

        val quality = channel.bestQuality
        if (quality.isNotEmpty()) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(Color(0x99000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(quality, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (favorite) {
            Icon(
                painter = painterResource(R.drawable.ic_star),
                contentDescription = "Favorito",
                tint = Color(0xFFFFC107),
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(16.dp),
            )
        }
    }
}

@Composable
private fun CenterMessage(text: String, action: String?, onAction: (() -> Unit)?) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(action) {
        if (action != null) {
            delay(60)
            runCatching { focus.requestFocus() }
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text, color = Palette.TextSecondary, fontSize = 16.sp, textAlign = TextAlign.Center)
            if (action != null && onAction != null) {
                Spacer(Modifier.height(16.dp))
                FocusTile(
                    modifier = Modifier.width(200.dp).height(46.dp),
                    focusRequester = focus,
                    shape = RoundedCornerShape(10.dp),
                    onClick = onAction,
                ) { focused ->
                    Box(
                        Modifier.matchParentSize().background(if (focused) Palette.PanelHi else Palette.Panel),
                        contentAlignment = Alignment.Center,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                painter = painterResource(R.drawable.ic_refresh),
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(action, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}
