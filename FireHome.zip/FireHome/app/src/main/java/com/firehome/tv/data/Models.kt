package com.firehome.tv.data

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap

/** Uma fonte de video de um canal (por exemplo, a versao HD ou FHD do mesmo canal). */
data class Source(val quality: String, val url: String)

data class Channel(
    val id: String,
    val name: String,
    val logo: String?,
    val group: String,
    val sources: List<Source>,
)

data class ChannelGroup(val name: String, val channels: List<Channel>)

/** Melhor qualidade disponivel entre as fontes do canal (vazio se nao houver informacao). */
val Channel.bestQuality: String
    get() = listOf("4K", "FHD", "HD", "SD").firstOrNull { q -> sources.any { it.quality == q } } ?: ""

/** App instalado no aparelho, com imagens ja reduzidas para economizar memoria. */
data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap?,
    val banner: ImageBitmap?,
)

/** Servico de streaming conhecido. [packages] sao os nomes de pacote possiveis na Fire TV. */
data class StreamingService(
    val id: String,
    val name: String,
    val packages: List<String>,
    val color: Color,
)

data class StreamingItem(val service: StreamingService, val app: AppEntry?)

data class AppsState(
    val streaming: List<StreamingItem>,
    val all: List<AppEntry>,
) {
    companion object {
        val Empty = AppsState(emptyList(), emptyList())
    }
}

object Cats {
    const val FAV = "__fav"
    const val ALL = "__all"
}
