package com.firehome.tv.data

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap

/** App instalado no aparelho, com imagens ja reduzidas para economizar memoria. */
data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap?,
    val banner: ImageBitmap?,
)

/** Servico de streaming conhecido. [packages] sao os nomes de pacote possiveis na Fire TV. */
data class StreamingService(
    val id: String,
    val name: String,
    val packages: List<String>,
    val color: Color,
)

data class StreamingItem(val service: StreamingService, val app: AppEntry?)

data class AppsState(
    val streaming: List<StreamingItem>,
    val all: List<AppEntry>,
) {
    companion object {
        val Empty = AppsState(emptyList(), emptyList())
    }
}
