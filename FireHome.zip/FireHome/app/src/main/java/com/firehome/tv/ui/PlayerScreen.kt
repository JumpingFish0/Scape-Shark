package com.firehome.tv.ui

import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.firehome.tv.data.Channel
import kotlinx.coroutines.delay

/**
 * Player em tela cheia.
 * Cima / baixo: troca de canal   Esquerda / direita: troca a qualidade
 * OK: mostra informacoes         Voltar: sai
 * Se uma fonte falhar, tenta a proxima fonte do mesmo canal automaticamente.
 */
@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    channel: Channel,
    onChannelChange: (delta: Int) -> Unit,
    onWatched: (Channel) -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val currentChannel by rememberUpdatedState(channel)

    var sourceIndex by remember(channel.id) { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(true) }
    var failed by remember(channel.id) { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(true) }
    var infoTick by remember { mutableIntStateOf(0) }
    val focus = remember { FocusRequester() }

    val player = remember {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 9; AFTMM) FireHome/1.0")
            .setConnectTimeoutMs(12_000)
            .setReadTimeoutMs(15_000)
            .setAllowCrossProtocolRedirects(true)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(8_000, 30_000, 1_500, 3_000)
            .build()
        ExoPlayer.Builder(context)
            .setLoadControl(load)
            .setMediaSourceFactory(HlsMediaSource.Factory(http).setAllowChunklessPreparation(true))
            .build()
            .apply { playWhenReady = true }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING || state == Player.STATE_IDLE
            }

            override fun onPlayerError(error: PlaybackException) {
                val last = currentChannel.sources.lastIndex
                if (sourceIndex < last) {
                    sourceIndex += 1
                } else {
                    failed = true
                    buffering = false
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(channel.id, sourceIndex) {
        val src = channel.sources.getOrNull(sourceIndex) ?: return@LaunchedEffect
        failed = false
        buffering = true
        player.setMediaItem(MediaItem.fromUri(src.url))
        player.prepare()
        player.playWhenReady = true
    }

    LaunchedEffect(channel.id) {
        onWatched(channel)
        showInfo = true
        infoTick++
        runCatching { focus.requestFocus() }
    }

    LaunchedEffect(infoTick) {
        if (showInfo) {
            delay(4_000)
            showInfo = false
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .focusable()
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (ev.key) {
                    Key.DirectionUp, Key.ChannelUp -> { onChannelChange(-1); true }
                    Key.DirectionDown, Key.ChannelDown -> { onChannelChange(+1); true }
                    Key.DirectionRight -> {
                        if (channel.sources.size > 1) {
                            sourceIndex = (sourceIndex + 1) % channel.sources.size
                        }
                        showInfo = true; infoTick++; true
                    }
                    Key.DirectionLeft -> {
                        if (channel.sources.size > 1) {
                            sourceIndex = (sourceIndex - 1 + channel.sources.size) % channel.sources.size
                        }
                        showInfo = true; infoTick++; true
                    }
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                        showInfo = !showInfo; infoTick++; true
                    }
                    else -> false
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val exo = player
                PlayerView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                    useController = false
                    isFocusable = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = exo
                    keepScreenOn = true
                }
            },
        )

        if (buffering && !failed) {
            Text(
                "Carregando...",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 14.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0x99000000), RoundedCornerShape(10.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }

        if (failed) {
            Column(
                Modifier
                    .align(Alignment.Center)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp))
                    .padding(horizontal = 26.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Canal indisponível", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Use cima e baixo para trocar de canal",
                    color = Palette.TextSecondary,
                    fontSize = 12.sp,
                )
            }
        }

        AnimatedVisibility(
            visible = showInfo,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            InfoBar(channel, sourceIndex)
        }
    }
}

@Composable
private fun InfoBar(channel: Channel, sourceIndex: Int) {
    val quality = channel.sources.getOrNull(sourceIndex)?.quality.orEmpty()
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
            .padding(horizontal = 48.dp)
            .padding(top = 40.dp, bottom = 28.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (channel.logo != null) {
                AsyncImage(
                    model = channel.logo,
                    contentDescription = null,
                    modifier = Modifier.size(54.dp),
                )
                Spacer(Modifier.width(16.dp))
            }
            Column {
                Text(channel.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                val sub = buildString {
                    append(channel.group)
                    if (quality.isNotEmpty()) append("  ·  ").append(quality)
                    if (channel.sources.size > 1) {
                        append("  ·  fonte ${sourceIndex + 1} de ${channel.sources.size}")
                    }
                }
                Text(sub, color = Palette.TextSecondary, fontSize = 13.sp)
                Text(
                    "Cima/Baixo: trocar canal   Esquerda/Direita: trocar qualidade",
                    color = Color.White.copy(alpha = 0.55f),
                    fontSize = 11.sp,
                )
            }
        }
    }
}
