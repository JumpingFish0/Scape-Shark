package com.firehome.tv.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

/** Abre apps, a loja da Fire TV e as configuracoes do aparelho. */
object AppLauncher {

    fun open(ctx: Context, pkg: String): Boolean {
        val pm = ctx.packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
            ?: pm.getLaunchIntentForPackage(pkg)
            ?: return false
        return start(ctx, intent)
    }

    /** Abre a pagina do app na loja da Fire TV (para instalar). */
    fun openStoreListing(ctx: Context, pkg: String, name: String) {
        val tries = listOf(
            Intent(Intent.ACTION_VIEW, Uri.parse("amzn://apps/android?p=$pkg")),
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")),
        )
        if (tries.none { start(ctx, it) }) {
            toast(ctx, "Abra a loja de apps e procure por $name")
        }
    }

    fun openStore(ctx: Context) {
        if (open(ctx, "com.amazon.venezia")) return
        val search = Intent(Intent.ACTION_VIEW, Uri.parse("amzn://apps/android?s=streaming"))
        if (!start(ctx, search)) toast(ctx, "Loja de apps indisponivel neste aparelho")
    }

    fun openSettings(ctx: Context) {
        val fallback = Intent().setClassName(
            "com.amazon.tv.settings.v2",
            "com.amazon.tv.settings.v2.tv.TvSettingsActivity",
        )
        val ok = start(ctx, Intent(Settings.ACTION_SETTINGS)) || start(ctx, fallback)
        if (!ok) toast(ctx, "Nao foi possivel abrir as configuracoes")
    }

    /** Tela de informacoes do app (permite desinstalar). */
    fun openAppDetails(ctx: Context, pkg: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
        if (!start(ctx, intent)) toast(ctx, "Nao foi possivel abrir os detalhes do app")
    }

    private fun start(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    private fun toast(ctx: Context, message: String) {
        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show()
    }
}
