package com.firehome.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.firehome.tv.data.AppConfig
import com.firehome.tv.data.AppLauncher
import com.firehome.tv.data.EmbeddedChannelsInstaller
import com.firehome.tv.data.AppEntry
import com.firehome.tv.ui.AllAppsScreen
import com.firehome.tv.ui.ProfilesScreen
import com.firehome.tv.ui.SearchScreen
import com.firehome.tv.ui.WeatherScreen
import com.firehome.tv.ui.FireHomeTheme
import com.firehome.tv.ui.HomeScreen
import com.firehome.tv.ui.Palette
import com.firehome.tv.ui.WallpaperScreen

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FireHomeTheme {
                Root(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Pode ter instalado ou removido apps enquanto estava fora da tela.
        vm.reloadApps()
        vm.loadWeather()
        EmbeddedChannelsInstaller.resumePendingInstall(this)
    }

    /** Botao Home com o launcher ja aberto: volta para a tela inicial. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.go(Screen.Home)
    }
}

@Composable
private fun Root(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Na Home nao ha para onde voltar: o Voltar e consumido para o launcher nao fechar.
    BackHandler(enabled = true) { vm.back() }

    val openApp: (AppEntry) -> Unit = { app ->
        if (AppLauncher.open(context, app.packageName)) vm.recordApp(app.packageName, app.label)
    }

    Box(Modifier.fillMaxSize().background(Palette.Bg)) {
        when (state.screen) {
            Screen.Home -> HomeScreen(
                apps = state.apps,
                initialFocusKey = state.homeFocus,
                onFocusKey = vm::setHomeFocus,
                profile = state.profile,
                weather = state.weather,
                recents = state.recents,
                wallpaper = state.wallpaper,
                onOpenChannels = {
                    EmbeddedChannelsInstaller.installOrOpen(this)
                    vm.recordApp(AppConfig.CHANNELS_PACKAGE, "Canais")
                },
                onOpenAllApps = { vm.go(Screen.AllApps) },
                onOpenStreaming = { item ->
                    val app = item.app
                    val opened = app != null && AppLauncher.open(context, app.packageName)
                    if (opened && app != null) {
                        vm.recordApp(app.packageName, app.label)
                    } else {
                        AppLauncher.openStoreListing(
                            context,
                            item.service.packages.first(),
                            item.service.name,
                        )
                    }
                },
                onOpenRecent = { r ->
                    if (AppLauncher.open(context, r.key)) vm.recordApp(r.key, r.label)
                },
                onOpenSearch = { vm.go(Screen.Search) },
                onOpenWeather = { vm.go(Screen.Weather); vm.loadWeather() },
                onOpenProfiles = { vm.go(Screen.Profiles) },
                onOpenStore = { AppLauncher.openStore(context) },
                onOpenWifi = { AppLauncher.openWifi(context) },
                onOpenWallpapers = { vm.go(Screen.Wallpapers) },
                onOpenSettings = { AppLauncher.openSettings(context) },
            )

            Screen.Profiles -> ProfilesScreen(
                profiles = state.profiles,
                currentId = state.profileId,
                wallpaper = state.wallpaper,
                onSelect = vm::selectProfile,
                onAdd = vm::addProfile,
                onSave = vm::renameProfile,
                onDelete = vm::deleteProfile,
            )

            Screen.Search -> SearchScreen(
                apps = state.apps.all,
                wallpaper = state.wallpaper,
                onOpenApp = openApp,
            )

            Screen.Weather -> WeatherScreen(
                weather = state.weather,
                failed = state.weatherFailed,
                results = state.placeResults,
                searching = state.placeSearching,
                searchFailed = state.placeSearchFailed,
                wallpaper = state.wallpaper,
                onSearch = vm::searchPlaces,
                onChoose = vm::choosePlace,
                onRefresh = { vm.loadWeather(force = true) },
            )

            Screen.Wallpapers -> WallpaperScreen(
                selected = state.wallpaper,
                onSelect = vm::setWallpaper,
            )

            Screen.AllApps -> AllAppsScreen(
                apps = state.apps.all,
                onOpen = openApp,
                onDetails = { AppLauncher.openAppDetails(context, it.packageName) },
            )
        }
    }
}
