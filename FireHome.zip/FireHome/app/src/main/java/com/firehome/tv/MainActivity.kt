package com.firehome.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.firehome.tv.data.AppLauncher
import com.firehome.tv.ui.AllAppsScreen
import com.firehome.tv.ui.ChannelsScreen
import com.firehome.tv.ui.FireHomeTheme
import com.firehome.tv.ui.HomeScreen
import com.firehome.tv.ui.Palette
import com.firehome.tv.ui.WallpaperScreen

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FireHomeTheme {
                Root(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Pode ter instalado ou removido apps enquanto estava fora da tela.
        vm.reloadApps()
    }

    /** Botao Home com o launcher ja aberto: volta para a tela inicial. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.go(Screen.Home)
    }
}

@Composable
private fun Root(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Na Home nao ha para onde voltar: o Voltar e consumido para o launcher nao fechar.
    BackHandler(enabled = true) { vm.back() }

    Box(Modifier.fillMaxSize().background(Palette.Bg)) {
        when (state.screen) {
            Screen.Home -> HomeScreen(
                apps = state.apps,
                initialFocusKey = state.homeFocus,
                onFocusKey = vm::setHomeFocus,
                onOpenChannels = { vm.go(Screen.Channels); vm.loadChannels() },
                wallpaper = state.wallpaper,
                onOpenWallpapers = { vm.go(Screen.Wallpapers) },
                onOpenAllApps = { vm.go(Screen.AllApps) },
                onOpenStreaming = { item ->
                    val app = item.app
                    val opened = app != null && AppLauncher.open(context, app.packageName)
                    if (!opened) {
                        AppLauncher.openStoreListing(
                            context,
                            item.service.packages.first(),
                            item.service.name,
                        )
                    }
                },
                onOpenStore = { AppLauncher.openStore(context) },
                onOpenWifi = { AppLauncher.openWifi(context) },
                onOpenSettings = { AppLauncher.openSettings(context) },
            )

            Screen.Channels -> ChannelsScreen(
                state = state.channels,
                wallpaper = state.wallpaper,
                onRetry = { vm.loadChannels(force = true) },
            )

            Screen.Wallpapers -> WallpaperScreen(
                selected = state.wallpaper,
                onSelect = vm::setWallpaper,
            )

            Screen.AllApps -> AllAppsScreen(
                apps = state.apps.all,
                onOpen = { AppLauncher.open(context, it.packageName) },
                onDetails = { AppLauncher.openAppDetails(context, it.packageName) },
            )
        }
    }
}
