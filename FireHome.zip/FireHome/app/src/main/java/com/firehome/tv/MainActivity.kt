package com.firehome.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.firehome.tv.data.AppConfig
import com.firehome.tv.data.AppLauncher
import com.firehome.tv.data.PlaylistUrl
import com.firehome.tv.data.Cats
import com.firehome.tv.ui.AllAppsScreen
import com.firehome.tv.ui.ChannelsScreen
import com.firehome.tv.ui.FireHomeTheme
import com.firehome.tv.ui.HomeScreen
import com.firehome.tv.ui.Palette
import com.firehome.tv.ui.PlayerScreen
import com.firehome.tv.ui.PlaylistScreen

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FireHomeTheme {
                Root(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Pode ter instalado ou removido apps enquanto estava fora da tela.
        vm.reloadApps()
    }

    /** Botao Home com o launcher ja aberto: volta para a tela inicial. */
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        vm.go(Screen.Home)
    }
}

@Composable
private fun Root(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Na Home nao ha para onde voltar: o Voltar e consumido para o launcher nao fechar.
    BackHandler(enabled = true) { vm.back() }

    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().background(Palette.Bg)) {
        when (state.screen) {
            Screen.Home -> HomeScreen(
                apps = state.apps,
                channelCount = state.groups.sumOf { it.channels.size },
                lastChannel = state.lastChannel,
                favoriteCount = state.favorites.size,
                playlistHost = PlaylistUrl.host(state.playlistUrl),
                initialFocusKey = state.homeFocus,
                onFocusKey = vm::setHomeFocus,
                onOpenChannels = { vm.openChannels(state.channelCategory) },
                onOpenFavorites = { vm.openChannels(Cats.FAV) },
                onOpenPlaylist = { vm.go(Screen.Playlist) },
                onContinue = vm::continueLast,
                onOpenAllApps = { vm.go(Screen.AllApps) },
                onOpenStreaming = { item ->
                    val app = item.app
                    val opened = app != null && AppLauncher.open(context, app.packageName)
                    if (!opened) {
                        AppLauncher.openStoreListing(
                            context,
                            item.service.packages.first(),
                            item.service.name,
                        )
                    }
                },
                onOpenStore = { AppLauncher.openStore(context) },
                onOpenSettings = { AppLauncher.openSettings(context) },
            )

            Screen.AllApps -> AllAppsScreen(
                apps = state.apps.all,
                onOpen = { AppLauncher.open(context, it.packageName) },
                onDetails = { AppLauncher.openAppDetails(context, it.packageName) },
            )

            Screen.Channels -> ChannelsScreen(
                groups = state.groups,
                favorites = state.favorites,
                loadState = state.loadState,
                startCategory = state.channelCategory,
                onCategory = vm::setChannelCategory,
                onPlay = vm::play,
                onToggleFavorite = vm::toggleFavorite,
                onRetry = { vm.loadChannels(force = true) },
                onChangePlaylist = { vm.go(Screen.Playlist) },
            )

            Screen.Playlist -> PlaylistScreen(
                currentUrl = state.playlistUrl,
                isDefault = state.playlistUrl == AppConfig.PLAYLIST_URL,
                onSave = vm::setPlaylist,
                onReset = vm::resetPlaylist,
            )

            Screen.Player -> state.playing?.let { channel ->
                PlayerScreen(
                    channel = channel,
                    onChannelChange = vm::changeChannel,
                    onWatched = vm::onWatched,
                )
            }
        }
    }
}
