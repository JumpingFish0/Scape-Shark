package com.firehome.tv.data

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Instala o APK de Canais que acompanha o FireHome, somente após confirmação do usuário. */
object EmbeddedChannelsInstaller {
    private const val APK_ASSET = "canais.apk"
    private const val PREFS = "embedded_channels_installer"
    private const val KEY_PENDING = "pending_install_after_settings"
    private const val CHANNELS_PACKAGE = "com.empresa.potiguar.de.comunicacao"

    fun installOrOpen(activity: Activity) {
        if (AppLauncher.open(activity, CHANNELS_PACKAGE)) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
                .edit().putBoolean(KEY_PENDING, true).apply()
            val settingsIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${activity.packageName}"),
            )
            try {
                activity.startActivity(settingsIntent)
            } catch (_: Exception) {
                toast(activity, "Autorize a instalação de apps desconhecidos para o FireHome nas configurações.")
            }
            return
        }
        launchInstaller(activity)
    }

    /** Chamado ao voltar das configurações: continua automaticamente se a permissão foi concedida. */
    fun resumePendingInstall(activity: Activity) {
        val prefs = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_PENDING, false)) return
        prefs.edit().remove(KEY_PENDING).apply()

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || activity.packageManager.canRequestPackageInstalls()) {
            launchInstaller(activity)
        } else {
            toast(activity, "A instalação não foi autorizada. Se quiser, tente novamente em Canais.")
        }
    }

    private fun launchInstaller(activity: Activity) {
        try {
            val apkDir = File(activity.cacheDir, "apks").apply { mkdirs() }
            val apkFile = File(apkDir, APK_ASSET)
            activity.assets.open(APK_ASSET).use { input ->
                apkFile.outputStream().use { output -> input.copyTo(output) }
            }

            val apkUri = FileProvider.getUriForFile(
                activity,
                "${activity.packageName}.fileprovider",
                apkFile,
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(installIntent)
        } catch (error: Exception) {
            toast(activity, "Não foi possível iniciar a instalação de Canais: ${error.localizedMessage ?: "erro desconhecido"}")
        }
    }

    private fun toast(activity: Activity, message: String) {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
    }
}
