package com.firehome.tv.data

object AppConfig {
    /** Lista M3U/M3U8 usada na area "Canais". */
    const val PLAYLIST_URL =
        "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/refs/heads/master/CanaisBR04.m3u8"

    /** Horas ate a lista em cache ser considerada velha e baixada de novo. */
    const val CACHE_TTL_HOURS = 6L

    /** Esconde categorias e canais adultos que existam na lista. */
    const val HIDE_ADULT = true
}
