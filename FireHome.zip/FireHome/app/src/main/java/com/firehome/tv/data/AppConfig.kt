package com.firehome.tv.data

object AppConfig {
    /** App externo de canais. O tile Canais abre ele. */
    const val CHANNELS_PACKAGE = "com.empresa.potiguar.de.comunicacao"
    const val CHANNELS_NAME = "o app de Canais"
}
