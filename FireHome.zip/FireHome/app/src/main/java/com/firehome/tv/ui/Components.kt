package com.firehome.tv.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.firehome.tv.R
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** O que o fundo da tela mostra em destaque para o item que esta com foco. */
data class FocusInfo(
    val key: String,
    val title: String,
    val subtitle: String,
    val color: Color,
    val image: ImageBitmap? = null,
    val icon: ImageBitmap? = null,
    val iconRes: Int? = null,
    val live: Boolean = false,
)

/**
 * Tile que aumenta e ganha borda quando recebe foco do controle remoto.
 * Aceita clique (OK) e clique longo / botao Menu para uma segunda acao.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FocusTile(
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    shape: Shape = RoundedCornerShape(6.dp),
    onFocus: () -> Unit = {},
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.(focused: Boolean) -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.07f else 1f, tween(130), label = "tile-scale")
    val interaction = remember { MutableInteractionSource() }

    Box(
        modifier
            .zIndex(if (focused) 2f else 0f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .onFocusChanged { state ->
                focused = state.isFocused
                if (state.isFocused) onFocus()
            }
            .onKeyEvent { ev ->
                if (onLongClick != null && ev.type == KeyEventType.KeyDown && ev.key == Key.Menu) {
                    onLongClick()
                    true
                } else {
                    false
                }
            }
            .clip(shape)
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onLongClick = onLongClick,
                onClick = onClick,
            )
    ) {
        content(focused)
        if (focused) {
            Box(Modifier.matchParentSize().border(3.dp, Palette.Focus, shape))
        }
    }
}

/** Arte vetorial da area de TV ao vivo, desenhada direto no Canvas (sem arquivo de imagem). */
fun Modifier.liveArt(cx: Float = 0.5f, cy: Float = 0.5f, unit: Float = 0.5f): Modifier =
    this.drawBehind {
        drawRect(
            Brush.linearGradient(
                listOf(Color(0xFF1A237E), Color(0xFF6A1B9A), Color(0xFF0A0D14)),
                start = Offset.Zero,
                end = Offset(size.width, size.height),
            )
        )
        val c = Offset(size.width * cx, size.height * cy)
        val m = size.minDimension
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0x55FFFFFF), Color.Transparent),
                center = c,
                radius = m * 0.7f,
            ),
            radius = m * 0.7f,
            center = c,
        )
        for (i in 1..4) {
            drawCircle(
                color = Color.White.copy(alpha = 0.10f),
                radius = m * 0.14f * i,
                center = c,
                style = Stroke(width = m * 0.008f),
            )
        }
        val w = m * unit
        val h = w * 0.62f
        val tl = Offset(c.x - w / 2f, c.y - h / 2f)
        drawRoundRect(
            Color(0xFF0E1220),
            topLeft = tl,
            size = Size(w, h),
            cornerRadius = CornerRadius(w * 0.07f),
        )
        drawRoundRect(
            Color.White,
            topLeft = tl,
            size = Size(w, h),
            cornerRadius = CornerRadius(w * 0.07f),
            style = Stroke(width = w * 0.03f),
        )
        val play = Path().apply {
            moveTo(c.x - w * 0.07f, c.y - h * 0.2f)
            lineTo(c.x - w * 0.07f, c.y + h * 0.2f)
            lineTo(c.x + w * 0.13f, c.y)
            close()
        }
        drawPath(play, Color.White)
        val stroke = w * 0.03f
        val standY = c.y + h / 2f + h * 0.12f
        drawLine(
            Color.White,
            Offset(c.x - w * 0.18f, standY),
            Offset(c.x + w * 0.18f, standY),
            strokeWidth = stroke,
            cap = StrokeCap.Round,
        )
        drawLine(
            Color.White,
            Offset(c.x, tl.y),
            Offset(c.x - w * 0.15f, tl.y - h * 0.28f),
            strokeWidth = stroke,
            cap = StrokeCap.Round,
        )
        drawLine(
            Color.White,
            Offset(c.x, tl.y),
            Offset(c.x + w * 0.15f, tl.y - h * 0.28f),
            strokeWidth = stroke,
            cap = StrokeCap.Round,
        )
    }

/** Fundo de tela cheia que troca com suavidade conforme o item em foco. */
@Composable
fun Backdrop(info: FocusInfo, modifier: Modifier = Modifier) {
    Crossfade(
        targetState = info,
        animationSpec = tween(420),
        modifier = modifier,
        label = "backdrop",
    ) { i ->
        val image = i.image
        val icon = i.icon
        val iconRes = i.iconRes
        Box(Modifier.fillMaxSize().background(Palette.Bg)) {
            when {
                i.live -> Box(Modifier.fillMaxSize().liveArt(0.74f, 0.42f, 0.5f))

                image != null -> {
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.linearGradient(listOf(i.color, Palette.Bg))
                        )
                    )
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.6f,
                    )
                }

                else -> {
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.linearGradient(
                                listOf(i.color.copy(alpha = 0.85f), Palette.Bg),
                                start = Offset.Zero,
                                end = Offset(2400f, 1400f),
                            )
                        )
                    )
                    when {
                        icon != null -> Image(
                            bitmap = icon,
                            contentDescription = null,
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 120.dp)
                                .size(220.dp),
                        )

                        iconRes != null -> Icon(
                            painter = painterResource(iconRes),
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 120.dp)
                                .size(200.dp),
                        )

                        else -> Text(
                            i.title,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 54.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 100.dp),
                        )
                    }
                }
            }
            // Escurece a esquerda e a base para os textos ficarem legiveis.
            Box(
                Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(0f to Color(0xD0000000), 0.75f to Color.Transparent)
                )
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(0.45f to Color.Transparent, 1f to Color(0xE6000000))
                )
            )
        }
    }
}

@Composable
fun TopBar(title: String? = null, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(R.drawable.ic_launcher),
            contentDescription = null,
            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)),
        )
        Spacer(Modifier.width(12.dp))
        Text(
            title ?: "Fire Home",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.weight(1f))
        Clock()
    }
}

@Composable
fun Clock() {
    val locale = remember { Locale.forLanguageTag("pt-BR") }
    val timeFormat = remember { SimpleDateFormat("HH:mm", locale) }
    val dateFormat = remember { SimpleDateFormat("EEE, d 'de' MMM", locale) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L + 20L)
        }
    }

    Column(horizontalAlignment = Alignment.End) {
        Text(
            timeFormat.format(Date(now)),
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            dateFormat.format(Date(now)).replaceFirstChar { it.uppercase() },
            color = Palette.TextSecondary,
            fontSize = 12.sp,
        )
    }
}
