package com.firehome.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.firehome.tv.R
import kotlinx.coroutines.delay

/**
 * Tela para trocar a playlist: o usuario digita (ou cola, ou dita) o endereco da lista M3U.
 * Dica: o app Fire TV do celular tem um teclado que digita direto no campo.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun PlaylistScreen(
    currentUrl: String,
    isDefault: Boolean,
    onSave: (String) -> String?,
    onReset: () -> Unit,
) {
    var text by remember { mutableStateOf(if (isDefault) "" else currentUrl) }
    var error by remember { mutableStateOf<String?>(null) }
    val field = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    fun save() {
        error = onSave(text)
    }

    LaunchedEffect(Unit) {
        delay(200)
        runCatching { field.requestFocus() }
        keyboard?.show()
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF131A2B), Palette.Bg))
        )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 48.dp)
                .padding(top = 26.dp, bottom = 20.dp)
        ) {
            TopBar(title = "Playlist de canais")
            Spacer(Modifier.height(24.dp))

            Text("Playlist atual", color = Palette.TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                currentUrl,
                color = Color.White,
                fontSize = 14.sp,
                maxLines = 2,
            )
            if (isDefault) {
                Spacer(Modifier.height(2.dp))
                Text("(lista padrão do launcher)", color = Palette.TextSecondary, fontSize = 12.sp)
            }

            Spacer(Modifier.height(22.dp))
            Text(
                "Novo endereço (link da lista .m3u ou .m3u8)",
                color = Palette.TextSecondary,
                fontSize = 12.sp,
            )
            Spacer(Modifier.height(6.dp))

            OutlinedTextField(
                value = text,
                onValueChange = {
                    text = it
                    error = null
                },
                modifier = Modifier.fillMaxWidth().focusRequester(field),
                singleLine = true,
                textStyle = TextStyle(fontSize = 16.sp, color = Color.White),
                placeholder = {
                    Text("https://exemplo.com/lista.m3u8", color = Color(0x80FFFFFF), fontSize = 16.sp)
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { save() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Palette.Focus,
                    unfocusedBorderColor = Color(0x66FFFFFF),
                    cursorColor = Palette.Focus,
                ),
            )

            val message = error
            if (message != null) {
                Spacer(Modifier.height(8.dp))
                Text(message, color = Color(0xFFFFB4A9), fontSize = 13.sp)
            }

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ActionButton("Salvar e carregar", R.drawable.ic_download, 210.dp) { save() }
                if (!isDefault) {
                    Spacer(Modifier.width(14.dp))
                    ActionButton("Restaurar padrão", R.drawable.ic_refresh, 190.dp) { onReset() }
                }
            }

            Spacer(Modifier.height(22.dp))
            Text(
                "Dicas",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "No celular, o app Fire TV (da Amazon) tem um teclado que digita direto neste campo, " +
                    "e você pode colar o link. Links do GitHub no formato github.com/.../blob/... " +
                    "são convertidos automaticamente. Se não digitar http ou https, o app usa https.",
                color = Palette.TextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
        }
    }
}

@Composable
private fun ActionButton(label: String, iconRes: Int, width: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    FocusTile(
        modifier = Modifier.width(width).height(46.dp),
        shape = RoundedCornerShape(10.dp),
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.matchParentSize().background(if (focused) Palette.PanelHi else Palette.Panel),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    painter = painterResource(iconRes),
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(label, color = Color.White, fontSize = 14.sp)
            }
        }
    }
}
