package com.firehome.tv.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/** Baixa a lista M3U, guarda uma copia local e entrega os canais ja organizados. */
class ChannelRepository(context: Context) {
    private val dir = context.applicationContext.filesDir
    private val cacheFile = File(dir, "playlist.m3u8")

    fun isStale(): Boolean {
        if (!cacheFile.exists()) return true
        val age = System.currentTimeMillis() - cacheFile.lastModified()
        return age > TimeUnit.HOURS.toMillis(AppConfig.CACHE_TTL_HOURS)
    }

    /** Le a copia local (rapido, funciona sem internet). */
    suspend fun cached(): List<ChannelGroup>? = withContext(Dispatchers.IO) {
        if (!cacheFile.exists()) null else runCatching { parseCache() }.getOrNull()
    }

    /** Baixa de novo e devolve a lista atualizada. Se falhar, lanca excecao. */
    suspend fun refresh(): List<ChannelGroup> = withContext(Dispatchers.IO) {
        download()
        parseCache()
    }

    private fun parseCache(): List<ChannelGroup> =
        cacheFile.bufferedReader(Charsets.UTF_8).use { M3uParser.parse(it) }

    private fun download() {
        val conn = URL(AppConfig.PLAYLIST_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "FireHome/1.0")
        try {
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("HTTP ${conn.responseCode}")
            }
            val tmp = File(dir, "playlist.tmp")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (tmp.length() < 100) throw IOException("Lista vazia")
            if (!tmp.renameTo(cacheFile)) {
                tmp.copyTo(cacheFile, overwrite = true)
                tmp.delete()
            }
        } finally {
            conn.disconnect()
        }
    }
}
