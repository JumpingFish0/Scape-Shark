package com.firehome.tv.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * Baixa a lista M3U, guarda uma copia local e entrega os canais ja organizados.
 * [urlProvider] devolve o endereco atual da playlist (o usuario pode troca-lo nas configuracoes).
 */
class ChannelRepository(
    context: Context,
    private val urlProvider: () -> String,
) {
    private val dir = context.applicationContext.filesDir
    private val cacheFile = File(dir, "playlist.m3u8")

    fun isStale(): Boolean {
        if (!cacheFile.exists()) return true
        val age = System.currentTimeMillis() - cacheFile.lastModified()
        return age > TimeUnit.HOURS.toMillis(AppConfig.CACHE_TTL_HOURS)
    }

    /** Apaga a copia local (usado quando a playlist e trocada). */
    fun clearCache() {
        cacheFile.delete()
    }

    /** Le a copia local (rapido, funciona sem internet). */
    suspend fun cached(): List<ChannelGroup>? = withContext(Dispatchers.IO) {
        if (!cacheFile.exists()) null
        else runCatching { parse(cacheFile) }.getOrNull()?.takeIf { it.isNotEmpty() }
    }

    /**
     * Baixa de novo e devolve a lista atualizada. Lanca excecao se falhar.
     * Um arquivo invalido (por exemplo uma pagina de erro) nunca substitui a lista que ja funciona.
     */
    suspend fun refresh(): List<ChannelGroup> = withContext(Dispatchers.IO) {
        val url = urlProvider()
        val tmp = File.createTempFile("playlist", ".tmp", dir)
        try {
            download(url, tmp)
            val groups = parse(tmp)
            if (groups.isEmpty()) throw IOException("Nenhum canal encontrado nessa lista")
            if (url != urlProvider()) throw IOException("Playlist trocada durante o download")
            if (!tmp.renameTo(cacheFile)) tmp.copyTo(cacheFile, overwrite = true)
            groups
        } finally {
            tmp.delete()
        }
    }

    private fun parse(file: File): List<ChannelGroup> =
        file.bufferedReader(Charsets.UTF_8).use { M3uParser.parse(it) }

    /** Segue ate 5 redirecionamentos, inclusive de http para https (o Java nao faz isso sozinho). */
    private fun download(startUrl: String, target: File) {
        var current = startUrl
        repeat(6) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "FireHome/1.0")
            try {
                when (val code = conn.responseCode) {
                    HttpURLConnection.HTTP_OK -> {
                        conn.inputStream.use { input -> target.outputStream().use { input.copyTo(it) } }
                        if (target.length() < 20) throw IOException("Lista vazia")
                        return
                    }

                    301, 302, 303, 307, 308 -> {
                        val location = conn.getHeaderField("Location")
                            ?: throw IOException("Redirecionamento sem destino")
                        current = URL(URL(current), location).toString()
                    }

                    else -> throw IOException("Servidor respondeu HTTP $code")
                }
            } finally {
                conn.disconnect()
            }
        }
        throw IOException("Redirecionamentos demais")
    }
}
