package com.firehome.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.firehome.tv.data.Place
import com.firehome.tv.data.Weather
import com.firehome.tv.data.WeatherRepository

@Composable
fun WeatherScreen(
    weather: Weather?,
    failed: Boolean,
    results: List<Place>,
    searching: Boolean,
    searchFailed: Boolean,
    wallpaper: Int,
    onSearch: (String) -> Unit,
    onChoose: (Place) -> Unit,
    onRefresh: () -> Unit,
) {
    var query by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().wallpaper(wallpaperAt(wallpaper))) {
        Box(Modifier.fillMaxSize().background(Color(0x88000000)))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 48.dp).padding(top = 26.dp, bottom = 20.dp)
        ) {
            TopBar(title = "Clima")
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxSize()) {
                // Tempo atual e proximos dias
                Column(Modifier.weight(1.2f)) {
                    if (weather == null) {
                        if (failed) {
                            Text("Não foi possível obter o clima", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text("Verifique a internet ou escolha uma cidade ao lado.", color = Palette.TextSecondary, fontSize = 13.sp)
                            Spacer(Modifier.height(14.dp))
                            Pill2("Tentar de novo", onRefresh)
                        } else {
                            Text("Carregando…", color = Palette.TextSecondary, fontSize = 16.sp)
                        }
                    } else {
                        Text(weather.place.name, color = Palette.TextSecondary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${weather.temp}°C", color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Bold)
                        Text(WeatherRepository.describe(weather.code), color = Color.White, fontSize = 20.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Sensação ${weather.feels}°C  ·  Umidade ${weather.humidity}%  ·  Vento ${weather.wind} km/h",
                            color = Palette.TextSecondary,
                            fontSize = 13.sp,
                        )
                        Spacer(Modifier.height(24.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            weather.days.forEach { d ->
                                Column(
                                    Modifier
                                        .width(84.dp)
                                        .background(Color(0x66161B27), RoundedCornerShape(14.dp))
                                        .padding(vertical = 12.dp, horizontal = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Text(d.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(6.dp))
                                    Text("${d.max}°", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("${d.min}°", color = Palette.TextSecondary, fontSize = 14.sp)
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        WeatherRepository.describe(d.code),
                                        color = Palette.TextSecondary,
                                        fontSize = 10.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.width(30.dp))

                // Trocar cidade
                Column(Modifier.weight(1f)) {
                    Text("TROCAR CIDADE", color = Palette.TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.6.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                        placeholder = { Text("Nome da cidade", color = Palette.TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Palette.Focus,
                            unfocusedBorderColor = Palette.Hairline,
                            cursorColor = Palette.Focus,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { onSearch(query) }),
                    )
                    Spacer(Modifier.height(10.dp))
                    Pill2("Buscar cidade") { onSearch(query) }
                    Spacer(Modifier.height(10.dp))
                    when {
                        searching -> Text("Buscando…", color = Palette.TextSecondary, fontSize = 13.sp)
                        searchFailed -> Text("Falha na busca. Tente de novo.", color = Palette.TextSecondary, fontSize = 13.sp)
                        else -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            results.forEach { p ->
                                FocusTile(
                                    modifier = Modifier.fillMaxWidth().height(44.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    onClick = { onChoose(p) },
                                ) { focused ->
                                    Box(
                                        Modifier.fillMaxSize()
                                            .background(if (focused) Color(0xF03A4A72) else Color(0xCC1A2030))
                                            .padding(horizontal = 14.dp),
                                        contentAlignment = Alignment.CenterStart,
                                    ) {
                                        Text(p.name, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Pill2(text: String, onClick: () -> Unit) {
    FocusTile(
        modifier = Modifier.width(170.dp).height(40.dp),
        shape = RoundedCornerShape(50),
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.fillMaxSize().background(if (focused) Color(0xF03A4A72) else Color(0xCC1E2536)),
            contentAlignment = Alignment.Center,
        ) {
            Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
