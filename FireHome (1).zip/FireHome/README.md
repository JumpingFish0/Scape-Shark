# Fire Home

Launcher para Fire TV Stick no estilo do painel do Xbox: o item em foco aparece grande no fundo.

- **Canais**: abre direto o app *Rei dos Canais* (`com.reidoscanais.tv`). Ele precisa estar instalado no aparelho (não vem junto).
- **Streaming**: Netflix, Prime Video, HBO Max etc. Se não estiver instalado, OK abre a página na loja.
- **Atalhos**: Todos os apps, Loja de apps, Rede, Configurações.
- Em "Todos os apps": segure OK ou aperte Menu para ver detalhes/desinstalar.

## Como gerar o APK

Android Studio: abra a pasta e rode `assembleRelease`.
Pelo celular: envie o zip para o GitHub; o workflow gera o APK em Releases.

## Personalizar

- `data/AppConfig.kt`: pacote do app de canais.
- `data/StreamingCatalog.kt`: lista de serviços, pacotes e cores.
