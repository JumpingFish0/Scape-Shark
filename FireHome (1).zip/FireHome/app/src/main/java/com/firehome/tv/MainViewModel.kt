package com.firehome.tv

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.firehome.tv.data.AppRepository
import com.firehome.tv.data.AppsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen { Home, AllApps }

data class UiState(
    val screen: Screen = Screen.Home,
    val apps: AppsState = AppsState.Empty,
    val homeFocus: String = "canais",
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val appRepo = AppRepository(app)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        reloadApps()
    }

    fun reloadApps() {
        viewModelScope.launch {
            val apps = appRepo.load()
            _state.update { it.copy(apps = apps) }
        }
    }

    fun go(screen: Screen) = _state.update { it.copy(screen = screen) }

    fun setHomeFocus(key: String) = _state.update { it.copy(homeFocus = key) }

    /** Trata o botao Voltar. Devolve false quando ja estiver na Home (nao ha para onde voltar). */
    fun back(): Boolean = when (_state.value.screen) {
        Screen.AllApps -> { go(Screen.Home); true }
        Screen.Home -> false
    }
}
