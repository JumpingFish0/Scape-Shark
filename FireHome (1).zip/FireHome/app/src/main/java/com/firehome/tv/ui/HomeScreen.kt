package com.firehome.tv.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.firehome.tv.R
import com.firehome.tv.data.AppConfig
import com.firehome.tv.data.AppsState
import com.firehome.tv.data.StreamingItem
import kotlinx.coroutines.delay

private const val KEY_CHANNELS = "canais"
private const val KEY_APPS = "apps"
private const val KEY_STORE = "store"
private const val KEY_WIFI = "wifi"
private const val KEY_SETTINGS = "settings"
private fun svcKey(id: String) = "svc:$id"

@Composable
fun HomeScreen(
    apps: AppsState,
    initialFocusKey: String,
    onFocusKey: (String) -> Unit,
    onOpenChannels: () -> Unit,
    onOpenAllApps: () -> Unit,
    onOpenStreaming: (StreamingItem) -> Unit,
    onOpenStore: () -> Unit,
    onOpenWifi: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val channelsApp = remember(apps) { apps.all.firstOrNull { it.packageName == AppConfig.CHANNELS_PACKAGE } }

    val channelsInfo = FocusInfo(
        key = KEY_CHANNELS,
        title = "Canais",
        subtitle = "TV ao vivo com o ${AppConfig.CHANNELS_NAME}",
        color = Color(0xFF3A1C71),
        icon = channelsApp?.icon,
        live = true,
        chip = if (channelsApp != null) "Instalado" else "Não instalado",
        chipColor = if (channelsApp != null) Palette.Ok else Palette.Warn,
    )
    val appsInfo = FocusInfo(
        key = KEY_APPS,
        title = "Todos os apps",
        subtitle = "${apps.all.size} apps instalados neste aparelho",
        color = Color(0xFF1F3A5F),
        iconRes = R.drawable.ic_apps,
    )
    val storeInfo = FocusInfo(
        key = KEY_STORE,
        title = "Loja de apps",
        subtitle = "Baixe novos apps na Appstore da Fire TV",
        color = Color(0xFFB45F06),
        iconRes = R.drawable.ic_store,
    )
    val wifiInfo = FocusInfo(
        key = KEY_WIFI,
        title = "Rede",
        subtitle = "Conectar ao Wi-Fi",
        color = Color(0xFF00695C),
        iconRes = R.drawable.ic_wifi,
    )
    val settingsInfo = FocusInfo(
        key = KEY_SETTINGS,
        title = "Configurações",
        subtitle = "Ajustes do aparelho",
        color = Color(0xFF37474F),
        iconRes = R.drawable.ic_settings,
    )

    fun streamingInfo(item: StreamingItem): FocusInfo {
        val app = item.app
        return FocusInfo(
            key = svcKey(item.service.id),
            title = item.service.name,
            subtitle = if (app != null) "Pressione OK para abrir" else "Pressione OK para instalar na loja",
            color = item.service.color,
            image = app?.banner,
            icon = if (app?.banner == null) app?.icon else null,
            chip = if (app != null) "Instalado" else "Não instalado",
            chipColor = if (app != null) Palette.Ok else Palette.Warn,
        )
    }

    val infos = remember(apps, channelsApp) {
        HashMap<String, FocusInfo>()
    }
    infos.clear()
    infos[KEY_CHANNELS] = channelsInfo
    infos[KEY_APPS] = appsInfo
    infos[KEY_STORE] = storeInfo
    infos[KEY_WIFI] = wifiInfo
    infos[KEY_SETTINGS] = settingsInfo
    apps.streaming.forEach { infos[svcKey(it.service.id)] = streamingInfo(it) }

    var focusKey by remember { mutableStateOf(initialFocusKey) }
    val current = infos[focusKey] ?: channelsInfo

    val requesters = remember { HashMap<String, FocusRequester>() }
    fun req(key: String) = requesters.getOrPut(key) { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(80)
        val target = if (infos.containsKey(initialFocusKey)) initialFocusKey else KEY_CHANNELS
        runCatching { req(target).requestFocus() }
    }

    fun focused(key: String) {
        focusKey = key
        onFocusKey(key)
    }

    Box(Modifier.fillMaxSize()) {
        Backdrop(current, Modifier.fillMaxSize())

        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 40.dp)
                .padding(top = 24.dp, bottom = 22.dp)
        ) {
            TopBar()
            Spacer(Modifier.height(18.dp))

            Row(Modifier.fillMaxSize()) {
                // Coluna da esquerda: Canais em destaque + todos os apps.
                Column(Modifier.width(244.dp)) {
                    ChannelsTile(
                        installed = channelsApp != null,
                        iconApp = channelsApp?.icon,
                        modifier = Modifier.fillMaxWidth().height(256.dp),
                        focusRequester = req(KEY_CHANNELS),
                        onFocus = { focused(KEY_CHANNELS) },
                        onClick = onOpenChannels,
                    )
                    Spacer(Modifier.height(44.dp))
                    GlassTile(
                        title = "Todos os apps",
                        subtitle = "${apps.all.size} instalados",
                        iconRes = R.drawable.ic_apps,
                        modifier = Modifier.fillMaxWidth().height(88.dp).padding(vertical = 0.dp),
                        focusRequester = req(KEY_APPS),
                        onFocus = { focused(KEY_APPS) },
                        onClick = onOpenAllApps,
                    )
                }

                Spacer(Modifier.width(36.dp))

                // Coluna da direita: titulo do item em foco + faixas de atalhos.
                Column(Modifier.fillMaxSize()) {
                    TitleBlock(current, Modifier.height(112.dp))
                    Spacer(Modifier.height(10.dp))
                    SectionLabel("STREAMING")
                    Spacer(Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                    ) {
                        items(apps.streaming, key = { it.service.id }) { item ->
                            val k = svcKey(item.service.id)
                            StreamingTile(
                                item = item,
                                focusRequester = req(k),
                                onFocus = { focused(k) },
                                onClick = { onOpenStreaming(item) },
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    SectionLabel("ATALHOS")
                    Spacer(Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                    ) {
                        item {
                            GlassTile(
                                title = "Loja de apps",
                                subtitle = "Appstore",
                                iconRes = R.drawable.ic_store,
                                modifier = Modifier.width(190.dp).height(88.dp),
                                focusRequester = req(KEY_STORE),
                                onFocus = { focused(KEY_STORE) },
                                onClick = onOpenStore,
                            )
                        }
                        item {
                            GlassTile(
                                title = "Rede",
                                subtitle = "Wi-Fi",
                                iconRes = R.drawable.ic_wifi,
                                modifier = Modifier.width(190.dp).height(88.dp),
                                focusRequester = req(KEY_WIFI),
                                onFocus = { focused(KEY_WIFI) },
                                onClick = onOpenWifi,
                            )
                        }
                        item {
                            GlassTile(
                                title = "Configurações",
                                subtitle = "Ajustes",
                                iconRes = R.drawable.ic_settings,
                                modifier = Modifier.width(190.dp).height(88.dp),
                                focusRequester = req(KEY_SETTINGS),
                                onFocus = { focused(KEY_SETTINGS) },
                                onClick = onOpenSettings,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        color = Palette.TextSecondary,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.6.sp,
        modifier = Modifier.padding(start = 8.dp),
    )
}

@Composable
private fun TitleBlock(info: FocusInfo, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(start = 8.dp), verticalArrangement = Arrangement.Bottom) {
        if (info.chip != null) {
            StatusChip(info.chip, info.chipColor)
            Spacer(Modifier.height(8.dp))
        }
        Text(
            info.title,
            color = Color.White,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            info.subtitle,
            color = Palette.TextSecondary,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ChannelsTile(
    installed: Boolean,
    iconApp: androidx.compose.ui.graphics.ImageBitmap?,
    modifier: Modifier,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    FocusTile(
        modifier = modifier,
        focusRequester = focusRequester,
        shape = RoundedCornerShape(18.dp),
        onFocus = onFocus,
        onClick = onClick,
    ) {
        Box(Modifier.fillMaxSize().liveArt(0.5f, 0.38f, 0.5f, tv = iconApp == null))
        if (iconApp != null) {
            Image(
                bitmap = iconApp,
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 34.dp)
                    .size(80.dp)
                    .clip(RoundedCornerShape(18.dp)),
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color(0xCC000000))
            )
        )
        Row(
            Modifier.align(Alignment.TopStart).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                Modifier
                    .background(Color(0xFFE53935), RoundedCornerShape(50))
                    .padding(horizontal = 9.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(6.dp).background(Color.White, CircleShape))
                Spacer(Modifier.width(5.dp))
                Text("AO VIVO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text("Canais", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(
                if (installed) "Abrir ${AppConfig.CHANNELS_NAME}" else "Instalar ${AppConfig.CHANNELS_NAME}",
                color = Color(0xFFE0E4EC),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun StreamingTile(
    item: StreamingItem,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    val app = item.app
    val banner = app?.banner
    val icon = app?.icon

    FocusTile(
        modifier = Modifier.width(176.dp).height(112.dp),
        focusRequester = focusRequester,
        shape = RoundedCornerShape(14.dp),
        onFocus = onFocus,
        onClick = onClick,
    ) {
        if (banner != null) {
            Box(Modifier.fillMaxSize().background(Palette.PanelHi))
            Image(
                bitmap = banner,
                contentDescription = item.service.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(listOf(item.service.color, Color(0xFF0E121C)))
                )
            )
            if (app != null && icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = item.service.name,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(bottom = 18.dp)
                        .size(46.dp)
                        .clip(RoundedCornerShape(10.dp)),
                )
            } else if (app == null) {
                Icon(
                    painter = painterResource(R.drawable.ic_download),
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.align(Alignment.Center).padding(bottom = 18.dp).size(34.dp),
                )
            }
            Column(
                Modifier.align(Alignment.BottomCenter).padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    item.service.name,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (app == null) {
                    Text("Instalar", color = Color(0xFFE0E4EC), fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun GlassTile(
    title: String,
    subtitle: String,
    iconRes: Int,
    modifier: Modifier,
    focusRequester: FocusRequester,
    onFocus: () -> Unit,
    onClick: () -> Unit,
) {
    FocusTile(
        modifier = modifier,
        focusRequester = focusRequester,
        shape = RoundedCornerShape(14.dp),
        onFocus = onFocus,
        onClick = onClick,
    ) { focused ->
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    if (focused) listOf(Color(0xF03A4A72), Color(0xF01E2740))
                    else listOf(Color(0xCC1E2536), Color(0xCC121724))
                )
            )
        )
        Row(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .background(if (focused) Color(0x33FFFFFF) else Color(0x1FFFFFFF), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(iconRes),
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp),
                )
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    subtitle,
                    color = Palette.TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
