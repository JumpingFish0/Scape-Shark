package com.firehome.tv.data

object AppConfig {
    /** App de canais ao vivo que o tile "Canais" abre. */
    const val CHANNELS_PACKAGE = "com.reidoscanais.tv"
    const val CHANNELS_NAME = "Rei dos Canais"
}
